<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kabid_controller extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('cuti');
		$this->load->model('pegawai');
		$this->load->model('sppd');
		$this->load->model('profil_pegawai');
		$this->load->model('profil_keluarga');
		$this->load->model('profil_pendidikan');
		$this->load->model('profil_diklat');		
		$this->load->model('profil_jenjangkarir');		
		$this->load->model('profil_pengalamankerja');
		$this->load->model('profil_organisasi');
		$this->load->model('profil_prestasi');
		$this->load->model('profil_penghargaan');
		$this->load->model('profil_sanksi');
		$this->load->model('daftar_agama');

		$role=$this->session->userdata('role');

		if ($role == 'User') {
			redirect('karyawan_controller');
		}else if ($role == 'Admin HRD') {
			redirect('hrd_controller');
		}else if($role=='') {
			redirect('login_controller');
		}else if ($role == 'Admin Kabid') {
		}

	}


	public function index()
	{	
		$data['notif']= $this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/index.php',$data);

	}

	function do_submission(){
		$tglmulai=new DateTime(substr($this->input->post('masacuti'),0, 10));
		$tglkembali=new DateTime(substr($this->input->post('masacuti'), 13,10));
		$sisacuti= $this->pegawai->get_sisacuti($nik=$this->session->userdata('nik'));
		$inserttglmulai=$tglmulai->format('Y/m/d');
		$inserttglkembali=$tglkembali->format('Y/m/d');

		$interval = DateInterval::createFromDateString('1 day');
		$period = new DatePeriod($tglmulai, $interval, $tglkembali);
		$lamacuti=1;

		foreach ($period as $dt) {
			$namahari=$dt->format('D');
			if($namahari!='Sat'&&$namahari!='Sun'){
				$lamacuti++;
			}
		}


		if ($sisacuti>=$lamacuti){
			$data = array(
			'nik' => $nik=$this->session->userdata('nik'),
			'macamcuti' => $this->input->post('macamcuti'),
			'tglmulai' => $inserttglmulai,
			'tglkembali' => $inserttglkembali,
			'lamacuti'=>$lamacuti,
			'outstandingtugas' => $this->input->post('outstandingtugas'),
			'petugaspengganti' => $this->input->post('pengganti'),
			'status' => 'Diajukan',
			'terbaca'=> false
			 );

			$numrow = $this->cuti->cek_cuti($nik);
			if($numrow==0){
				$this->cuti->insert_submission($data);
			}else if ($numrow==1){
				$this->cuti->update_submission($data, $nik);
			}
			$this->session->set_flashdata('reportsubmission', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Pengajuan Cuti Sukses!!!</h5></div>');



		}else{
			$this->session->set_flashdata('reportsubmission', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Pengambilan Cuti Salah!!!</h5></div>');

		}
		redirect('Kabid_controller/submission');
	}

	function set_datauser()
	{
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$data['datauser']=$this->pegawai->get_data($this->session->userdata('nik')); //set data user
		$data['tgllahir']= date("d-m-Y", strtotime($user->tgllahir)); //set tanggal lahir
		$data['tglmasuk']= date("d-m-Y", strtotime($user->tglmasuk)); // set tanggal masuk
		$data['tglpensiun']= $user->tglpensiun; // set tanggal masuk
		$data['namafoto']=$user->foto_pegawai;
		$bidang=$user->bidang;
		$data['cutimelahirkan']=$this->cuti->cari_kabid_cuti('Cuti Melahirkan', $bidang);
		$data['cutikhusus']=$this->cuti->cari_kabid_cuti('Cuti Khusus', $bidang);
		$data['cutibesar']=$this->cuti->cari_kabid_cuti('Cuti Besar', $bidang);
		$data['cutitahunan']=$this->cuti->cari_kabid_cuti('Cuti Tahunan', $bidang);

		return $data;
	}

	function do_acc(){
		$nonik = $this->uri->segment(3);
		$lamacuti = $this->uri->segment(4);// mengambil nilai lamacuti
		$nik	= $this->uri->segment(5); //mengambil nilai cuti


		$sisacuti = $this->pegawai->get_sisacuti($nik); //mengambil nilai sisa cuti
		$cutitersisa=$sisacuti-$lamacuti; // sisacuti yang tersisa

		$tglkembali = $this->cuti->get_tglkembali($nocuti); //mengambil tanggal kembali
		$tglbebascuti = date('Y-m-d', strtotime($tglkembali . " +90 days")); //menambahkan 90 hari setelah cuti

		$this->pegawai->update_tglbebascuti($nik, $tglbebascuti);  //update tanggal bebas cuti
		$this->pegawai->update_sisacuti($cutitersisa, $nik); //update sisacuti

		$user=$this->pegawai->get_user($this->session->userdata('nik')); 		//mendapatkan data user dalam row
		$namaadmin= $user->namalengkap;					// mendapatkan nama admin


		$this->cuti->acc_tahap1($nonik,$namaadmin);
		$this->session->set_flashdata('report', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Konfirmasi Cuti Sukses!!!</h5></div>');
		redirect('kabid_controller/listsubmission');

	}

	function do_decline(){
		$nonik = $this->uri->segment(3);

		$user=$this->pegawai->get_user($this->session->userdata('nik')); 		//mendapatkan data user dalam row
		$namaadmin= $user->namalengkap;					// mendapatkan nama admin

		$status= $this->cuti->decline($nonik, $namaadmin);
		$this->session->set_flashdata('report', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Tolak Cuti Sukses!!!</h5></div>');
		redirect('kabid_controller/listsubmission');
	}

	function do_changepassword()
	{
		$user=$this->pegawai->get_user($this->session->userdata('nik')); 		//mendapatkan data user dalam row
		$passasli= $user->password;					// mendapatkan password user
		$passlama=$this->input->post('passlama');	// mendapatkan pasword lama dari form sebelumnya
		$passlama=hash('sha256', sha1($passlama));	// melakukan hashing
		$passbaru1=$this->input->post('passbaru1'); // mendapatkan password baru1 dari form
		$passbaru1=hash('sha256', sha1($passbaru1));// melakukan hashing
		$passbaru2=$this->input->post('passbaru2'); // mendapatkan password baru2 dari form
		$passbaru2=hash('sha256', sha1($passbaru2));// melakukan hashing

		if ($passasli==$passlama && $passbaru1==$passbaru2){
			$this->pegawai->change_password($passbaru1);
			$this->session->set_flashdata('ubahpass', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Ubah Password Berhasil!!!</h5></div>');

			redirect('kabid_controller/password');
		}else{
			$this->session->set_flashdata('ubahpass', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:red;">Ubah Password Gagal!!!</h5></div>');
			redirect('kabid_controller/password');
		}
	}
	function do_submitsppd(){

		$berangkat= new DateTime($this->input->post('tglberangkat'));
		$kembali= new DateTime($this->input->post('tglkembali'));
		$lamahari= $berangkat->diff($kembali)->format ("%d")+1;

		$daftarpegawai=$this->input->post('pegawai');	// mendapatkan pasword lama dari form sebelumnya
		$tujuanperjalanan=$this->input->post('tujuanperjalanan'); // mendapatkan password baru1 dari form
		$maksudperjalanan=$this->input->post('maksudperjalanan'); // mendapatkan password baru2 dari form
		$tipetrans=$this->input->post('tipetransport'); // mendapatkan password baru2 dari form
		$tglberangkat= date("Y-m-d",strtotime($this->input->post('tglberangkat'))); // mendapatkan password baru2 dari form
		$tglkembali=date("Y-m-d",strtotime($this->input->post('tglkembali'))); // mendapatkan password baru2 dari form

		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$namakabid=$user->namalengkap;

		$namapegawai="";

		foreach ($this->input->post('pegawai') as $pegawai) {
			if($namapegawai==""){
				$namapegawai.=$pegawai;				
			}else{
				$namapegawai.=", ".$pegawai;
			}
		}
		$daftarpegawai=$namapegawai;
		$data = array(
			'nik_kabid' => $nik=$this->session->userdata('nik'),
			'pegawai' => $daftarpegawai,
			'tujuanperjalanan' => $tujuanperjalanan,
			'maksudperjalanan' => $maksudperjalanan,
			'tipetransport' => $tipetrans,
			'tglberangkat' => $tglberangkat,
			'tglkembali' => $tglkembali,
			'lamahari' => $lamahari,
			'status' => 'Diajukan',
			'penyetujukabid'=> $namakabid,
			'terbaca' => false
		);
		$this->sppd->insert_SPPD($data);
		$this->session->set_flashdata('submitsuccess', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Pengajuan SPPD Sukses!!!</h5></div>');

		redirect('kabid_controller/submissionsppd');
	}


	function listsubmission(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifcutitahap1']>0){
			$this->cuti->updatenotiftahap1();
			$data['notif']=$this->set_notification();
		}

		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;

		$data['listsubmission'] = $this->cuti->get_listsubmission('Diajukan', $bidang);		
		$data['datauser']= $this->set_datauser();
		$this->load->view('admin_kabid/cuti/listsubmission.php',$data);	
	}

	function submission(){
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;
		$data['petugaspengganti']=$this->pegawai->get_petugassebidang($bidang);
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$tglbebascuti=$this->pegawai->get_tglbebascuti($this->session->userdata('nik'));
		if (date("Y-m-d")>=$tglbebascuti){
			$this->load->view('admin_kabid/cutiku/submission.php', $data);
		}else{
			$this->session->set_flashdata('disable_button', 'disabled');
			$this->load->view('admin_kabid/cutiku/submission.php', $data);
		}
	}

	function do_updateprofilkeluarga(){
		$jumlahbaris=count($this->input->post('status'));
		$this->profil_keluarga->delete_datakeluarga();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$tgllahir=$this->input->post('tgllahir')[$i];

			$born_date	= new DateTime($tgllahir);
			$now 		= new DateTime('today');
			$datakeluarga = array(
				'nik' => $this->session->userdata('nik'),
				'status' => $this->input->post('status')[$i],
				'nama'=>$this->input->post('nama')[$i],
				'tgllahir'=>date("Y-m-d",strtotime($tgllahir)),
				'usia'=> $born_date->diff($now)->y
				 );
			$this->profil_keluarga->insert_datakeluarga($datakeluarga);
		}
		redirect('kabid_controller/keluarga');
	}
	function do_updateprofilpendidikan(){
		$jumlahbaris=count($this->input->post('jenis'));
		$this->profil_pendidikan->delete_datapendidikan();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datapendidikan = array(
				'nik' => $this->session->userdata('nik'),
				'jenis' => $this->input->post('jenis')[$i],
				'keterangan'=>$this->input->post('keterangan')[$i],
				'jurusan' => $this->input->post('jurusan')[$i],
				'thnlulus' => $this->input->post('thnlulus')[$i]
				 );
			$this->profil_pendidikan->insert_datapendidikan($datapendidikan);
		}
		redirect('kabid_controller/pendidikan');
	}

	function do_updateprofildiklat(){
		$jumlahbaris=count($this->input->post('namadiklat'));
		$this->profil_diklat->delete_datadiklat();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datadiklat = array(
				'nik' => $this->session->userdata('nik'),
				'namadiklat' => $this->input->post('namadiklat')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_diklat->insert_datadiklat($datadiklat);
		}
		redirect('kabid_controller/diklat');
	}

	function do_updateprofiljenjangkarir(){
		$jumlahbaris=count($this->input->post('jabatan'));
		$this->profil_jenjangkarir->delete_datajenjangkarir();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datajenjangkarir = array(
				'nik' => $this->session->userdata('nik'),
				'jabatan' =>$this->input->post('jabatan')[$i],
				'tglsk' => date("Y-m-d",strtotime($this->input->post('tglsk')[$i])),
				'nosk' =>$this->input->post('nosk')[$i],
				'berakhirsk' => date("Y-m-d",strtotime($this->input->post('berakhirsk')[$i])),
				'keterangan'=>$this->input->post('keterangan')[$i]
			);
			$this->profil_jenjangkarir->insert_datajenjangkarir($datajenjangkarir);
		}
		redirect('kabid_controller/karir');
	}

	function do_updateprofilpengalamankerja(){
		$jumlahbaris=count($this->input->post('pengalamankerja'));
		$this->profil_pengalamankerja->delete_datapengalamankerja();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'pengalamankerja' => $this->input->post('pengalamankerja')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_pengalamankerja->insert_datapengalamankerja($data);
		}
		redirect('kabid_controller/pengalamankerja');
	}

	function do_updateprofilorganisasi(){
		$jumlahbaris=count($this->input->post('organisasi'));
		$this->profil_organisasi->delete_dataorganisasi();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'organisasi' => $this->input->post('organisasi')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_organisasi->insert_dataorganisasi($data);
		}
		redirect('kabid_controller/organisasi');
	}

	function do_updateprofilprestasi(){
		$jumlahbaris=count($this->input->post('prestasi'));
		$this->profil_prestasi->delete_dataprestasi();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'prestasi' => $this->input->post('prestasi')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_prestasi->insert_dataprestasi($data);
		}
		redirect('kabid_controller/prestasi');
	}

	function do_updateprofilpenghargaan(){
		$jumlahbaris=count($this->input->post('penghargaan'));
		$this->profil_penghargaan->delete_datapenghargaan();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'penghargaan' => $this->input->post('penghargaan')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_penghargaan->insert_datapenghargaan($data);
		}
		redirect('kabid_controller/penghargaan');
	}

	function editprofile(){
		$this->load->helper('file');

        $nmfile =$this->session->userdata('nik'); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] = './assets/uploads/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] = '2048'; //maksimum besar file 2M
        $config['max_width']  = '5000'; //lebar maksimum 1288 px
        $config['max_height']  = '2000'; //tinggi maksimu 768 px
        $config['file_name'] = $nmfile; //nama yang terupload nantinya
        $config['overwrite'] = TRUE; //nama yang terupload nantinya


       $this->upload->initialize($config);

        if($_FILES['photo']['name'])
       {
       	echo "ada foto";
           if ($this->upload->do_upload('photo'))
           {
               $gbr = $this->upload->data();

				$tglpensiun=date("d-m-", strtotime($this->input->post('tgllahir')));
				$tglpensiun.= date("Y", strtotime($this->input->post('tgllahir')))+56;

				$pegawai = array(
					'nik' => $this->input->post('nik'),
					'namalengkap' => $this->input->post('namalengkap'),
					'namapanggilan' => $this->input->post('namapanggilan'),
					'statuspegawai' => $this->input->post('statuspegawai'),
					'bidang' => $this->input->post('bidang'),
					'tgllahir' => date("Y-m-d",strtotime($this->input->post('tgllahir'))),
					'tglmasuk' => date("Y-m-d",strtotime($this->input->post('tglmasuk'))),
					'tglpensiun' => $tglpensiun,
					'foto_pegawai'=> $gbr['file_name']
				);
				echo "dan berhasil upload";

           }else{  /* jika upload gambar gagal maka akan menjalankan skrip ini */
               $er_upload=$this->upload->display_errors(); /* untuk melihat error uploadnya apa */
               //pesan yang muncul jika terdapat error dimasukkan pada session flashdata
               $this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\">Gagal edit dan upload gambar !! ".$er_upload."</div>");
               redirect('kabid_controller/biodata');
           }
       }else{ /* jika file foto tidak ada maka query yg dijalankan adalah skrip ini  */
       	echo "ga ada foto";
	 
	     		$tglpensiun=date("d-m-", strtotime($this->input->post('tgllahir')));
				$tglpensiun.= date("Y", strtotime($this->input->post('tgllahir')))+56;

				$pegawai = array(
				'nik' => $this->input->post('nik'),
				'namalengkap' => $this->input->post('namalengkap'),
				'namapanggilan' => $this->input->post('namapanggilan'),
				'statuspegawai' => $this->input->post('statuspegawai'),
				'bidang' => $this->input->post('bidang'),
				'tgllahir' => date("Y-m-d",strtotime($this->input->post('tgllahir'))),
				'tglmasuk' => date("Y-m-d",strtotime($this->input->post('tglmasuk'))),
				'tglpensiun' => $tglpensiun
				);
	
       }

		$biodatapegawai = array(
			'nik' => $this->input->post('nik'),
			'jeniskelamin' => $this->input->post('jeniskelamin'),
			'dasarpenerimaan' => $this->input->post('dasarpenerimaan'),
			'agama' => $this->input->post('agama'),
			'sukubangsa' => $this->input->post('sukubangsa'),
			'golongandarah' => $this->input->post('goldar'),
			'tinggibadan' => $this->input->post('tinggibadan'),
			'beratbadan' => $this->input->post('beratbadan'),
			'hobi' => $this->input->post('hobi'),
			'mottohidup' => $this->input->post('mottohidup'),
			'noktp' => $this->input->post('noktp'),
			'alamatktp' => $this->input->post('alamatktp'),
			'alamatsekarang' => $this->input->post('alamatsekarang'),
			'email' => $this->input->post('email'),
			'status' => $this->input->post('status'),
			'nokk' => $this->input->post('nokk'),
			'bpjs' => $this->input->post('nobpjs'),
			'nosepatu' => $this->input->post('nosepatu'),
			'ukuranseragam' => $this->input->post('ukuranseragam'),
			'namaibukandung' => $this->input->post('namaibukandung'),
			'namaayahkandung' => $this->input->post('namaayahkandung'),
			'keahliankhusus' => $this->input->post('keahliankhusus'),
			'bahasadikuasai' => $this->input->post('bahasadikuasai'),
			'hasilmedical' =>$this->input->post('medicalcheckup') 
			 );
		$this->pegawai->update_pegawai($pegawai);
		$this->profil_pegawai->update_profilpegawai($biodatapegawai);
		$this->session->set_userdata('nik', $this->input->post('nik'));
		redirect('kabid_controller/biodata');
	}

	function cetakcuti()
	{			
		$nocuti = $this->uri->segment(3);//mengambil nilai nomor cuti
		$data['data']= $this->cuti->get_infoprint($nocuti);
		$this->load->view('print/cetakcuti.php', $data);
	}
	function cetaksppd()
	{			
		$nosppd = $this->uri->segment(3);//mengambil nilai nomor cuti
		$data['data']= $this->sppd->get_infoprint($nosppd);
		$this->load->view('print/cetaksppd.php',$data);
	}
	
	function set_notification(){
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;
		$data['notifcutitahap1']=$this->cuti->get_notifcutidiajukan1($bidang)?:"";
		$data['notifcutiditerima']=$this->cuti->get_notifcutiditerima() ?:"";
		$data['notifsppd']=$this->sppd->get_notifsppd() ?:"";


		return $data;
	}

	function history(){
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;
		$data['notif']=$this->set_notification();
		$data['datauser']= $this->set_datauser();
		$data['listhistory'] = $this->cuti->get_kabid_listhistory($bidang);
		$this->load->view('admin_kabid/cuti/history.php',$data);
	}

	function myhistory(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifcutiditerima']>0){
			$this->cuti->updatenotif();
			$data['notif']=$this->set_notification();
		}
		$data['datauser']= $this->set_datauser();
		$data['listhistory'] = $this->cuti->get_listmyhistory($this->session->userdata('nik'));
		$this->load->view('admin_kabid/cutiku/myhistory.php',$data);
	}

	function historysppd(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifsppd']>0){
			$this->sppd->updatenotifsppd();
			$data['notif']=$this->set_notification();
		}

		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;
		$data['sppd']=$this->sppd->get_kabid_listsppd($bidang);

		$data['datauser']= $this->set_datauser();
		$this->load->view('admin_kabid/sppd/historysppd.php',$data);
	}

	function submissionsppd(){
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;

		$data['notif']=$this->set_notification();
		$data['pegawai']=$this->pegawai->get_petugassebidang($bidang);
		$data['datauser']= $this->set_datauser();
		$this->load->view('admin_kabid/sppd/submissionsppd.php', $data);
	}

	function listsppd(){
		$data['notif']=$this->set_notification();
		$data= $this->set_datauser();
		$data['listsubmission'] = $this->cuti->get_listsubmission('Diajukan');
		$this->load->view('admin_kabid/sppd/listsppd.php', $data);
	}

	function password(){
		$data['notif']=$this->set_notification();
		$data['datauser']= $this->set_datauser();
		$this->load->view('admin_kabid/password/pass.php', $data);
	}

	function biodata(){
		$data['agama']=$this->daftar_agama->get_daftaragama();
		$data['notif']=$this->set_notification();
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/biodata.php', $data);
	}

	function keluarga(){
		$data['notif']=$this->set_notification();
		$data['datakeluarga']=$this->profil_keluarga->get_datakeluarga($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();

		$jumlahbaris = count($data['datakeluarga']);
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$tgllahir = $data['datakeluarga'][$i]['tgllahir'];
			$born_date	= new DateTime($tgllahir);
			$now 		= new DateTime('today');
			$usia= $born_date->diff($now)->y;
			$this->profil_keluarga->update_usia($usia, $this->session->userdata('nik'));
		}
		$data['datakeluarga']=$this->profil_keluarga->get_datakeluarga($this->session->userdata('nik'));
		
		$this->load->view('admin_kabid/profil/keluarga.php', $data);
	}

	function pendidikan(){
		$data['notif']=$this->set_notification();
		$data['pendidikan']= $this->profil_pendidikan->get_datapendidikan($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/pendidikan.php', $data);
	}

	function diklat(){
		$data['notif']=$this->set_notification();
		$data['diklat']= $this->profil_diklat->get_datadiklat($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/diklat.php', $data);
	}

	function karir(){
		$data['notif']=$this->set_notification();
		$data['jenjangkarir']=$this->profil_jenjangkarir->get_datajenjangkarir($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/karir.php', $data);
	}

	function pengalamankerja(){
		$data['notif']=$this->set_notification();
		$data['pengalamankerja']=$this->profil_pengalamankerja->get_datapengalamankerja($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/pengalamankerja.php', $data);
	}

	function prestasi(){
		$data['notif']=$this->set_notification();
		$data['prestasi']=$this->profil_prestasi->get_dataprestasi($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/prestasi.php', $data);
	}

	function organisasi(){
		$data['notif']=$this->set_notification();
		$data['organisasi']=$this->profil_organisasi->get_dataorganisasi($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/organisasi.php', $data);
	}

	function penghargaan(){
		$data['notif']=$this->set_notification();
		$data['penghargaan']=$this->profil_penghargaan->get_datapenghargaan($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/penghargaan.php', $data);
	}

	function sanksi(){
		$data['notif']=$this->set_notification();
		$data['sanksi']=$this->profil_sanksi->get_datasanksi($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/sanksi.php', $data);
	}

	function prev(){
		$data['notif']=$this->set_notification();
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datakeluarga']=$this->profil_keluarga->get_datakeluarga($this->session->userdata('nik'));
		$data['pendidikan']= $this->profil_pendidikan->get_datapendidikan($this->session->userdata('nik'));
		$data['diklat']= $this->profil_diklat->get_datadiklat($this->session->userdata('nik'));
		$data['jenjangkarir']=$this->profil_jenjangkarir->get_datajenjangkarir($this->session->userdata('nik'));
		$data['pengalamankerja']=$this->profil_pengalamankerja->get_datapengalamankerja($this->session->userdata('nik'));
		$data['prestasi']=$this->profil_prestasi->get_dataprestasi($this->session->userdata('nik'));
		$data['organisasi']=$this->profil_organisasi->get_dataorganisasi($this->session->userdata('nik'));
		$data['penghargaan']=$this->profil_penghargaan->get_datapenghargaan($this->session->userdata('nik'));
		$data['sanksi']=$this->profil_sanksi->get_datasanksi($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_kabid/profil/prevcetak.php', $data);
	}

}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class profil_pegawai extends CI_Model {

	function get_biodata($nik){
		$query = $this->db->get_where('profil_pegawai',array('nik' => $nik));
		$query = $query->result_array();
		return $query;
	}
	function update_profilpegawai($data){
		$this->db->set($data);
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->update('profil_pegawai');
	}

	function update_profilpegawai_hrd($data, $nik){
		$this->db->set($data);
		$this->db->where('nik', $nik);
		$this->db->update('profil_pegawai');
	}


	function get_allbiodata(){
		$this->db->from('profil_pegawai');
		$this->db->join('pegawai', 'pegawai.nik=profil_pegawai.nik');
		return $this->db->get()->result_array();
	}

}
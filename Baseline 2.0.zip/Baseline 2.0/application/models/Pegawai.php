<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pegawai extends CI_Model {

	function cek_login($nik="",$password=""){
		$query = $this->db->get_where('pegawai',array('nik' => $nik, 'password' => $password));
		return $query;
	}
	function cek_user($nik){
		$this->db->where('nik', $nik);
		return $this->db->get('pegawai')->num_rows();
	}

	function get_user($nik){
		$this->db->where('nik', $nik);
		return $this->db->get('pegawai')->row();
	}

	function get_data($nik){
		$this->db->from('pegawai');
		$this->db->join('profil_pegawai', 'profil_pegawai.nik=pegawai.nik');
		$this->db->where('pegawai.nik', $nik);
		return $this->db->get()->result_array();
	}

	function change_password($password){
		$this->db->set('password', $password);
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->update('pegawai');
	}

	function reset_password($nik){
		$new_password = hash('sha256', sha1($nik));
		$this->db->set('password', $new_password);
		$this->db->where('nik', $nik);
		$this->db->update('pegawai');
	}
	function changeaccess($nik, $role){
		$this->db->set('role', $role);
		$this->db->where('nik', $nik);
		$this->db->update('pegawai');
	}
	function deleteaccount($nik){
		$this->db->delete('pegawai', array('nik' => $nik));
		$this->db->delete('profil_pegawai', array('nik' => $nik));
	}

	function get_sisacuti($nik)
	{
		$this->db->select('sisacuti');
		$this->db->from('pegawai');
		$this->db->where('nik', $nik);
		$sisa=$this->db->get()->row();
		return $sisa->sisacuti;
	}

	function update_sisacuti($cutitersisa, $nik)
	{
		$this->db->set('sisacuti', $cutitersisa);
		$this->db->where('nik', $nik);
		$this->db->update('pegawai');
	}

	function update_tglbebascuti($nik, $tglbebascuti){
		$this->db->set('tglbebascuti',$tglbebascuti);
		$this->db->where('nik', $nik);
		$this->db->update('pegawai');
	}

	function get_tglbebascuti($nik)
	{
		$this->db->select('tglbebascuti');
		$this->db->from('pegawai');
		$this->db->where('nik', $nik);
		$sisa=$this->db->get()->row();
		return $sisa->tglbebascuti;
	}
	function get_alluser(){
		$this->db->from('pegawai');
		$this->db->join('profil_pegawai', 'profil_pegawai.nik=pegawai.nik');
		return $this->db->get()->result_array();
	}

	function update_pegawai($data){
		$this->db->set($data);
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->update('pegawai');
	}

	function update_pegawai_hrd($data, $nik){
		$this->db->set($data);
		$this->db->where('nik', $nik);
		$this->db->update('pegawai');
	}
	
	function get_petugassebidang($bidang){
		$this->db->from('pegawai');
		$this->db->where('bidang',$bidang);
		$this->db->where('nik!=', $this->session->userdata('nik'));
		$query = $this->db->get();
		return $query->result_array();
	}
	function update_bidangdefault($bidang){
		$this->db->set('bidang', '-');
		$this->db->where('bidang', $bidang);
		$this->db->update('pegawai');
	}

	function get_datakabid(){
		$this->db->from('pegawai');
		$this->db->where('role', 'Admin Kabid');
		$this->db->group_by('bidang');
		$query = $this->db->get();
		return $query->result_array();
	}

	function resetjatahcuti(){
		$this->db->trans_start();
		$this->db->trans_strict(FALSE);
		$this->db->query('UPDATE pegawai SET pegawai.sisacuti=8 WHERE pegawai.sisacuti>=0');
		$this->db->query('UPDATE pegawai SET pegawai.sisacuti=pegawai.sisacuti+8 WHERE pegawai.sisacuti<0');
		$this->db->trans_complete();
	}
	
}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class profil_jenjangkarir extends CI_Model {

	function get_datajenjangkarir($nik){
		$data = $this->db->where('nik', $nik);
		$data = $this->db->get('profil_jenjangkarir');
		return $data->result_array();
	}
	function insert_datajenjangkarir($data){
		$this->db->insert('profil_jenjangkarir',$data);
	}

	function delete_datajenjangkarir(){
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->delete('profil_jenjangkarir');
	}

	function get_alldatajenjangkarir(){
		$this->db->from('profil_jenjangkarir');
		$this->db->join('pegawai', 'pegawai.nik=profil_jenjangkarir.nik');
		return $this->db->get()->result_array();
	}

	function update_nik($nik, $nikbaru){
		$this->db->set('nik', $nikbaru);
		$this->db->where('nik', $nik);
		$this->db->update('profil_jenjangkarir');
	}


}
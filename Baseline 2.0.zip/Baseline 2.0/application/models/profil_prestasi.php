<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class profil_prestasi extends CI_Model {

	function get_dataprestasi($nik){
		$data = $this->db->where('nik', $nik);
		$data = $this->db->get('profil_prestasi');
		return $data->result_array();
	}
	function insert_dataprestasi($data){
		$this->db->insert('profil_prestasi',$data);
	}

	function delete_dataprestasi(){
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->delete('profil_prestasi');
	}

	function get_alldataprestasi(){
		$this->db->from('profil_prestasi');
		$this->db->join('pegawai', 'pegawai.nik=profil_prestasi.nik');
		return $this->db->get()->result_array();
	}

	function update_nik($nik, $nikbaru){
		$this->db->set('nik', $nikbaru);
		$this->db->where('nik', $nik);
		$this->db->update('profil_prestasi');
	}


}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_controller extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('pegawai');
		$this->load->model('daftar_status');
		$this->load->model('daftar_bidang');
		$this->load->model('daftar_dasarpenerimaan');
	}

	public function index()
	{
		$role=$this->session->userdata('role');

		if ($role == 'User') {
			redirect('karyawan_controller');
		}else if ($role == 'Admin Kabid') {
			redirect('kabid_controller');
		}else if ($role == 'Admin HRD') {
			redirect('hrd_controller');
		}else {
			$this->load->view('login');
		}



	}

	function do_login(){
		$nik = $this->input->post('nik');
		$password = $this->input->post('password');
		$password = hash('sha256', sha1($password));

		$data = $this->pegawai->cek_login($nik, $password);
			if($data->num_rows()=='1' && $data->row()->password==$password){
				$user=$this->pegawai->get_user($nik);
				$this->session->set_userdata(array(
					'nik' => $nik, //set session username
					'role' => $user->role
					));
				redirect('login_controller');
			}else{
				$this->session->set_flashdata('gagallogin', '<br><font style="color:red;">Username atau Password salah</font>');
				$this->load->view('login');
			}
	}

	function register(){
		$data['bidang']=$this->daftar_bidang->get_daftarbidang();
		$data['dasarpenerimaan']=$this->daftar_dasarpenerimaan->get_daftardasarpenerimaan();
		$data['statuspegawai']=$this->daftar_status->get_daftarstatus();
		$this->load->view('register.php', $data);
	}
}

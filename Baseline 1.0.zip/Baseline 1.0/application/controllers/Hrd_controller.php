<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hrd_controller extends CI_Controller {

	function __construct(){
		parent:: __construct();
		$this->load->model('cuti');
		$this->load->model('sppd');
		$this->load->model('pegawai');
		$this->load->model('pendaftaran_pegawai');
		$this->load->model('profil_pegawai');
		$this->load->model('profil_keluarga');
		$this->load->model('profil_pendidikan');
		$this->load->model('profil_diklat');		
		$this->load->model('profil_jenjangkarir');		
		$this->load->model('profil_pengalamankerja');
		$this->load->model('profil_organisasi');
		$this->load->model('profil_prestasi');
		$this->load->model('profil_penghargaan');
		$this->load->model('profil_sanksi');
		$this->load->model('daftar_bidang');
		$this->load->model('daftar_dasarpenerimaan');
		$this->load->model('daftar_agama');
		$this->load->model('daftar_status');

		$role=$this->session->userdata('role');
		if ($role == 'User') {
			redirect('karyawan_controller');
		}else if ($role == 'Admin Kabid') {
			redirect('kabid_controller');
		}else if($role=='') {
			redirect('login_controller');
		}else if ($role == 'Admin HRD') {
		}
	}


	public function index()
	{		
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();

		$this->load->view('admin_hrd/index.php',$data);
	}

	function do_submission(){
		$nik=$this->session->userdata('nik');
		$tglmulai=new DateTime(substr($this->input->post('masacuti'),0, 10));
		$tglkembali=new DateTime(substr($this->input->post('masacuti'), 13,10));
		$sisacuti= $this->pegawai->get_sisacuti($nik);
		$inserttglmulai=$tglmulai->format('Y/m/d');
		$inserttglkembali=$tglkembali->format('Y/m/d');

		$interval = DateInterval::createFromDateString('1 day');
		$period = new DatePeriod($tglmulai, $interval, $tglkembali);
		$lamacuti=1;

		foreach ($period as $dt) {
			$namahari=$dt->format('D');
			if($namahari!='Sat'&&$namahari!='Sun'){
				$lamacuti++;
			}
		}


		if ($sisacuti>=$lamacuti){
			$data = array(
			'nik' => $nik,
			'macamcuti' => $this->input->post('macamcuti'),
			'tglmulai' => $inserttglmulai,
			'tglkembali' => $inserttglkembali,
			'lamacuti'=>$lamacuti,
			'outstandingtugas' => $this->input->post('outstandingtugas'),
			'petugaspengganti' => $this->input->post('pengganti'),
			'status' => 'Diajukan',
			'terbaca' => false
			 );


			$numrow = $this->cuti->cek_cuti($nik);
			if($numrow==0){
				$this->cuti->insert_submission($data);
			}else if ($numrow==1){
				$this->cuti->update_submission($data, $nik);
			}
			$this->session->set_flashdata('reportsubmission', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Pengajuan Cuti Sukses!!!</h5></div>');
		}else{
			$this->session->set_flashdata('reportsubmission', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Pengambilan Cuti Salah!!!</h5></div>');
		}
		redirect('hrd_controller/submission');
	}
	function do_specialsubmission(){
		$nik = $this->input->post('nik');
		$tglmulai=new DateTime(substr($this->input->post('masacuti'),0, 10));
		$tglkembali=new DateTime(substr($this->input->post('masacuti'), 13,10));
		$lamacuti= $tglmulai->diff($tglkembali)->format ("%d")+1;
		$sisacuti= $this->pegawai->get_sisacuti($nik);
		$inserttglmulai=$tglmulai->format('Y/m/d');
		$inserttglkembali=$tglkembali->format('Y/m/d');

		$sisacuti = $this->pegawai->get_sisacuti($nik); //mengambil nilai sisa cuti
		$cutitersisa=$sisacuti-$lamacuti; // sisacuti yang tersisa

		$tglbebascuti = date('Y-m-d', strtotime($inserttglkembali . " +90 days")); //menambahkan 90 hari setelah cuti

		$user=$this->pegawai->get_user($this->session->userdata('nik'));

		$data = array(
		'nik' => $nik,
		'macamcuti' => $this->input->post('macamcuti'),
		'tglmulai' => $inserttglmulai,
		'tglkembali' => $inserttglkembali,
		'lamacuti'=>$lamacuti,
		'status' => 'Dikonfirmasi',
		'penyetujukabid'=> 'Admin Kabid',
		'penyetujuhrd'=> $user->namalengkap,
		'petugaspengganti'=> $this->input->post('pengganti'),
		'terbaca' => false
		 );

		$this->pegawai->update_tglbebascuti($nik, $tglbebascuti);  //update tanggal bebas cuti
		$this->pegawai->update_sisacuti($cutitersisa, $nik); //update sisacuti
		$this->cuti->insert_submission($data);

		$this->session->set_flashdata('reportsubmission', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Pendaftaran Cuti Sukses!!!</h5></div>');

		redirect('hrd_controller/cutikhusus');
	}

	function set_datauser(){
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$data['datauser']=$this->pegawai->get_data($this->session->userdata('nik')); //set data user
		$data['tgllahir']= date("d-m-Y", strtotime($user->tgllahir)); //set tanggal lahir
		$data['tglmasuk']= date("d-m-Y", strtotime($user->tglmasuk)); // set tanggal masuk
		$data['tglpensiun']= $user->tglpensiun; // set tanggal masuk
		$data['namafoto']=$user->foto_pegawai;
		$data['cutimelahirkan']=$this->cuti->cari_all_cuti('Cuti Melahirkan');
		$data['cutikhusus']=$this->cuti->cari_all_cuti('Cuti Khusus');
		$data['cutibesar']=$this->cuti->cari_all_cuti('Cuti Besar');
		$data['cutitahunan']=$this->cuti->cari_all_cuti('Cuti Tahunan');

		return $data;	
	}


	function do_changepassword()
	{
		$user=$this->pegawai->get_user($this->session->userdata('nik')); 		//mendapatkan data user dalam row
		$passasli= $user->password;					// mendapatkan password user
		$passlama=$this->input->post('passlama');	// mendapatkan pasword lama dari form sebelumnya
		$passlama=hash('sha256', sha1($passlama));	// melakukan hashing
		$passbaru1=$this->input->post('passbaru1'); // mendapatkan password baru1 dari form
		$passbaru1=hash('sha256', sha1($passbaru1));// melakukan hashing
		$passbaru2=$this->input->post('passbaru2'); // mendapatkan password baru2 dari form
		$passbaru2=hash('sha256', sha1($passbaru2));// melakukan hashing

		if ($passasli==$passlama && $passbaru1==$passbaru2){
			$this->pegawai->change_password($passbaru1);
			$this->session->set_flashdata('ubahpass', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Ubah Password Berhasil!!!</h5></div>');

			redirect('hrd_controller/password');
		}else{
			$this->session->set_flashdata('ubahpass', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:red;">Ubah Password Gagal!!!</h5></div>');
			redirect('hrd_controller/password');
		}
	}

	function listsubmission(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifcutitahap2']>0){
			$this->cuti->updatenotiftahap2();
			$data['notif']=$this->set_notification();
		}
		$data['datauser']=$this->set_datauser();
		$data['listsubmission'] = $this->cuti->get_all_listsubmission('Diterima');
		$this->load->view('admin_hrd/cuti/listsubmission.php',$data);	
	}


	function do_acccuti(){
		$nocuti = $this->uri->segment(3);//mengambil nilai nomor cuti

		$user=$this->pegawai->get_user($this->session->userdata('nik')); 		//mendapatkan data user dalam row
		$namaadmin= $user->namalengkap;					// mendapatkan nama admin

		$this->cuti->acc_tahap2($nocuti, $namaadmin); //update status cuti menjadi "Dikonfirmasi"
		$this->session->set_flashdata('report', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Konfirmasi Cuti Sukses!!!</h5></div>');
		redirect('hrd_controller/listsubmission');
	}

	function do_accregistrasi(){
		$nik = $this->uri->segment(3);
		$role = str_replace('%20', ' ', $this->uri->segment(4));		
		$data= $this->pendaftaran_pegawai->get_spesificpendaftar($nik);
		$data_array = array(
			'nik' =>$data[0]['nik'] , 
			'password' => $data[0]['password'] , 
			'namalengkap' =>$data[0]['namalengkap'] , 
			'namapanggilan' =>$data[0]['namapanggilan'] , 
			'foto_pegawai' =>'Default.jpg' , 
			'role' => $role , 
			'statuspegawai' =>$data[0]['statuspegawai'] , 
			'bidang' =>$data[0]['bidang'] , 
			'tgllahir' =>$data[0]['tgllahir'] , 
			'tglmasuk' =>$data[0]['tglmasuk'] , 
			'tglpensiun' =>$data[0]['tglpensiun'] , 
			'tglbebascuti' =>$data[0]['tglbebascuti'] , 
			'sisacuti' =>$data[0]['sisacuti']  
		);
		$data_array2 = array(
			'nik' => $data[0]['nik'],  
			'dasarpenerimaan' => $data[0]['dasarpenerimaan']  
		);
		$this->pendaftaran_pegawai->insert_pegawai($nik, $data_array, $data_array2);	
		redirect('hrd_controller/registrasi');
	}
	function do_declineregistrasi(){
		$nik = $this->uri->segment(3);
		$this->pendaftaran_pegawai->remove_pegawai($nik);
		redirect('hrd_controller/registrasi');
	}


	function submission(){
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$bidang=$user->bidang;
		$data['petugaspengganti']=$this->pegawai->get_petugassebidang($bidang);
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$tglbebascuti=$this->pegawai->get_tglbebascuti($this->session->userdata('nik'));
		if (date("Y-m-d")>=$tglbebascuti){
			$this->load->view('admin_hrd/cutiku/submission.php', $data);
		}else{
			$this->session->set_flashdata('disable_button', 'disabled');
			$this->load->view('admin_hrd/cutiku/submission.php', $data);
		}
	}

		function do_updateprofilkeluarga(){
		$jumlahbaris=count($this->input->post('status'));
		$this->profil_keluarga->delete_datakeluarga();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$tgllahir=$this->input->post('tgllahir')[$i];

			$born_date	= new DateTime($tgllahir);
			$now 		= new DateTime('today');
			$datakeluarga = array(
				'nik' => $this->session->userdata('nik'),
				'status' => $this->input->post('status')[$i],
				'nama'=>$this->input->post('nama')[$i],
				'tgllahir'=>date("Y-m-d",strtotime($tgllahir)),
				'usia'=> $born_date->diff($now)->y
				 );
			$this->profil_keluarga->insert_datakeluarga($datakeluarga);
		}
		redirect('hrd_controller/keluarga');
	}
	function do_updateprofilpendidikan(){
		$jumlahbaris=count($this->input->post('jenis'));
		$this->profil_pendidikan->delete_datapendidikan();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datapendidikan = array(
				'nik' => $this->session->userdata('nik'),
				'jenis' => $this->input->post('jenis')[$i],
				'keterangan'=>$this->input->post('keterangan')[$i],
				'jurusan' => $this->input->post('jurusan')[$i],
				'thnlulus' => $this->input->post('thnlulus')[$i]
				 );
			$this->profil_pendidikan->insert_datapendidikan($datapendidikan);
		}
		redirect('hrd_controller/pendidikan');
	}

	function do_updateprofildiklat(){
		$jumlahbaris=count($this->input->post('namadiklat'));
		$this->profil_diklat->delete_datadiklat();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datadiklat = array(
				'nik' => $this->session->userdata('nik'),
				'namadiklat' => $this->input->post('namadiklat')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_diklat->insert_datadiklat($datadiklat);
		}
		redirect('hrd_controller/diklat');
	}

	function do_updateprofiljenjangkarir(){
		$jumlahbaris=count($this->input->post('jabatan'));
		$this->profil_jenjangkarir->delete_datajenjangkarir();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datajenjangkarir = array(
				'nik' => $this->session->userdata('nik'),
				'jabatan' =>$this->input->post('jabatan')[$i],
				'tglsk' => date("Y-m-d",strtotime($this->input->post('tglsk')[$i])),
				'nosk' =>$this->input->post('nosk')[$i],
				'berakhirsk' => date("Y-m-d",strtotime($this->input->post('berakhirsk')[$i])),
				'keterangan'=>$this->input->post('keterangan')[$i]
			);
			$this->profil_jenjangkarir->insert_datajenjangkarir($datajenjangkarir);
		}
		redirect('hrd_controller/karir');
	}

	function do_updateprofilpengalamankerja(){
		$jumlahbaris=count($this->input->post('pengalamankerja'));
		$this->profil_pengalamankerja->delete_datapengalamankerja();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'pengalamankerja' => $this->input->post('pengalamankerja')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_pengalamankerja->insert_datapengalamankerja($data);
		}
		redirect('hrd_controller/pengalamankerja');
	}

	function do_updateprofilorganisasi(){
		$jumlahbaris=count($this->input->post('organisasi'));
		$this->profil_organisasi->delete_dataorganisasi();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'organisasi' => $this->input->post('organisasi')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_organisasi->insert_dataorganisasi($data);
		}
		redirect('hrd_controller/organisasi');
	}

	function do_updateprofilprestasi(){
		$jumlahbaris=count($this->input->post('prestasi'));
		$this->profil_prestasi->delete_dataprestasi();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'prestasi' => $this->input->post('prestasi')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_prestasi->insert_dataprestasi($data);
		}
		redirect('hrd_controller/prestasi');
	}

	function do_updateprofilpenghargaan(){
		$jumlahbaris=count($this->input->post('penghargaan'));
		$this->profil_penghargaan->delete_datapenghargaan();
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data = array(
				'nik' => $this->session->userdata('nik'),
				'penghargaan' => $this->input->post('penghargaan')[$i],
				'tahun'=>$this->input->post('tahun')[$i]
			);
			$this->profil_penghargaan->insert_datapenghargaan($data);
		}
		redirect('hrd_controller/penghargaan');
	}

	function editprofile(){
		$this->load->helper('file');

        $nmfile =$this->session->userdata('nik'); //nama file saya beri nama langsung dan diikuti fungsi time
        $config['upload_path'] = './assets/uploads/'; //path folder
        $config['allowed_types'] = 'gif|jpg|png|jpeg|bmp'; //type yang dapat diakses bisa anda sesuaikan
        $config['max_size'] = '2048'; //maksimum besar file 2M
        $config['max_width']  = '5000'; //lebar maksimum 1288 px
        $config['max_height']  = '2000'; //tinggi maksimu 768 px
        $config['file_name'] = $nmfile; //nama yang terupload nantinya
        $config['overwrite'] = TRUE; //nama yang terupload nantinya


       $this->upload->initialize($config);

        if($_FILES['photo']['name'])
       {
       	echo "ada foto";
           if ($this->upload->do_upload('photo'))
           {
               $gbr = $this->upload->data();

				$tglpensiun=date("d-m-", strtotime($this->input->post('tgllahir')));
				$tglpensiun.= date("Y", strtotime($this->input->post('tgllahir')))+56;

				$pegawai = array(
					'nik' => $this->input->post('nik'),
					'namalengkap' => $this->input->post('namalengkap'),
					'namapanggilan' => $this->input->post('namapanggilan'),
					'statuspegawai' => $this->input->post('statuspegawai'),
					'bidang' => $this->input->post('bidang'),
					'tgllahir' => date("Y-m-d",strtotime($this->input->post('tgllahir'))),
					'tglmasuk' => date("Y-m-d",strtotime($this->input->post('tglmasuk'))),
					'tglpensiun' => $tglpensiun,
					'foto_pegawai'=> $gbr['file_name']
				);
				echo "dan berhasil upload";

           }else{  /* jika upload gambar gagal maka akan menjalankan skrip ini */
               $er_upload=$this->upload->display_errors(); /* untuk melihat error uploadnya apa */
               //pesan yang muncul jika terdapat error dimasukkan pada session flashdata
               $this->session->set_flashdata("pesan", "<div class=\"alert alert-danger\" id=\"alert\">Gagal edit dan upload gambar !! ".$er_upload."</div>");
               redirect('hrd_controller/biodata');
           }
       }else{ /* jika file foto tidak ada maka query yg dijalankan adalah skrip ini  */
       	echo "ga ada foto";
	 
	     		$tglpensiun=date("d-m-", strtotime($this->input->post('tgllahir')));
				$tglpensiun.= date("Y", strtotime($this->input->post('tgllahir')))+56;

				$pegawai = array(
				'nik' => $this->input->post('nik'),
				'namalengkap' => $this->input->post('namalengkap'),
				'namapanggilan' => $this->input->post('namapanggilan'),
				'statuspegawai' => $this->input->post('statuspegawai'),
				'bidang' => $this->input->post('bidang'),
				'tgllahir' => date("Y-m-d",strtotime($this->input->post('tgllahir'))),
				'tglmasuk' => date("Y-m-d",strtotime($this->input->post('tglmasuk'))),
				'tglpensiun' => $tglpensiun
				);
	
       }

		$biodatapegawai = array(
			'nik' => $this->input->post('nik'),
			'jeniskelamin' => $this->input->post('jeniskelamin'),
			'dasarpenerimaan' => $this->input->post('dasarpenerimaan'),
			'agama' => $this->input->post('agama'),
			'sukubangsa' => $this->input->post('sukubangsa'),
			'golongandarah' => $this->input->post('goldar'),
			'tinggibadan' => $this->input->post('tinggibadan'),
			'beratbadan' => $this->input->post('beratbadan'),
			'hobi' => $this->input->post('hobi'),
			'mottohidup' => $this->input->post('mottohidup'),
			'noktp' => $this->input->post('noktp'),
			'alamatktp' => $this->input->post('alamatktp'),
			'alamatsekarang' => $this->input->post('alamatsekarang'),
			'email' => $this->input->post('email'),
			'status' => $this->input->post('status'),
			'nokk' => $this->input->post('nokk'),
			'bpjs' => $this->input->post('nobpjs'),
			'nosepatu' => $this->input->post('nosepatu'),
			'ukuranseragam' => $this->input->post('ukuranseragam'),
			'namaibukandung' => $this->input->post('namaibukandung'),
			'namaayahkandung' => $this->input->post('namaayahkandung'),
			'keahliankhusus' => $this->input->post('keahliankhusus'),
			'bahasadikuasai' => $this->input->post('bahasadikuasai'),
			'hasilmedical' =>$this->input->post('medicalcheckup') 
			 );
		$this->pegawai->update_pegawai($pegawai);
		$this->profil_pegawai->update_profilpegawai($biodatapegawai);
		$this->session->set_userdata('nik', $this->input->post('nik'));
		redirect('hrd_controller/biodata');
	}

	function edit_profilepegawai(){
		$nik = $this->uri->segment(3);//mengambil nilai nik
		$tglpensiun=date("d-m-", strtotime($this->input->post('tgllahir')));
		$tglpensiun.= date("Y", strtotime($this->input->post('tgllahir')))+56;

		$pegawai = array(
			'nik' => $this->input->post('nik'),
			'namalengkap' => $this->input->post('namalengkap'),
			'namapanggilan' => $this->input->post('namapanggilan'),
			'statuspegawai' => $this->input->post('statuspegawai'),
			'bidang' => $this->input->post('bidang'),
			'tgllahir' => date("Y-m-d",strtotime($this->input->post('tgllahir'))),
			'tglmasuk' => date("Y-m-d",strtotime($this->input->post('tglmasuk'))),
			'tglpensiun' => $tglpensiun
			);

		$biodatapegawai = array(
			'nik' => $this->input->post('nik'),
			'jeniskelamin' => $this->input->post('jeniskelamin'),
			'dasarpenerimaan' => $this->input->post('penerimaan'),
			'agama' => $this->input->post('agama'),
			'sukubangsa' => $this->input->post('suku'),
			'golongandarah' => $this->input->post('golongandarah'),
			'tinggibadan' => $this->input->post('tinggibadan'),
			'beratbadan' => $this->input->post('beratbadan'),
			'hobi' => $this->input->post('hobi'),
			'mottohidup' => $this->input->post('motto'),
			'noktp' => $this->input->post('noktp'),
			'alamatktp' => $this->input->post('alamatktp'),
			'alamatsekarang' => $this->input->post('alamatsekarang'),
			'email' => $this->input->post('email'),
			'status' => $this->input->post('status'),
			'nokk' => $this->input->post('nokk'),
			'bpjs' => $this->input->post('nobpjs'),
			'nosepatu' => $this->input->post('nosepatu'),
			'ukuranseragam' => $this->input->post('seragam'),
			'namaibukandung' => $this->input->post('namaibukandung'),
			'namaayahkandung' => $this->input->post('namaayahkandung'),
			'keahliankhusus' => $this->input->post('keahliankhusus'),
			'bahasadikuasai' => $this->input->post('bahasadikuasai'),
			'hasilmedical' =>$this->input->post('medical') 
			 );

		$jumlahbaris=count($this->input->post('tglsanksi'));
		$this->profil_sanksi->delete_datasanksi($nik);
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$datasanksi= array(
				'nik' => $nik,
				'tglsanksi' => date("Y-m-d", strtotime($this->input->post('tglsanksi')[$i])),
				'keterangan' => $this->input->post('keterangan')[$i],
				'berakhir' => date("Y-m-d", strtotime($this->input->post('berakhir')[$i])),
				'status' => $this->input->post('statussanksi')[$i]
				 );
			$this->profil_sanksi->insert_datasanksi($datasanksi);
		}

		$this->cuti->update_nik($nik, $this->input->post('nik'));
		$this->profil_diklat->update_nik($nik, $this->input->post('nik'));
		$this->profil_jenjangkarir->update_nik($nik, $this->input->post('nik'));
		$this->profil_keluarga->update_nik($nik, $this->input->post('nik'));
		$this->profil_organisasi->update_nik($nik, $this->input->post('nik'));
		$this->profil_pendidikan->update_nik($nik, $this->input->post('nik'));
		$this->profil_pengalamankerja->update_nik($nik, $this->input->post('nik'));
		$this->profil_penghargaan->update_nik($nik, $this->input->post('nik'));
		$this->profil_prestasi->update_nik($nik, $this->input->post('nik'));
		$this->profil_sanksi->update_nik($nik, $this->input->post('nik'));

		$this->pegawai->update_pegawai_hrd($pegawai, $nik);
		$this->profil_pegawai->update_profilpegawai_hrd($biodatapegawai, $nik);
		redirect('hrd_controller/pegawai');
	}

	function set_notification(){
		$data['notifcutitahap2']=$this->cuti->get_notifcutidiajukan2()?:"";
		$data['notifcutiditerima']=$this->cuti->get_notifcutiditerima() ?:"";
		$data['notifsppd']=$this->sppd->get_notifpengajuansppd() ?:"";
		$data['notifregistrasi']=$this->pendaftaran_pegawai->get_notifpendaftaran()?:"";
		return $data;
	}

	function do_accsppd(){
		$nosppd = $this->uri->segment(3);//mengambil nilai nomor cuti
		$user=$this->pegawai->get_user($this->session->userdata('nik'));
		$namahrd=$user->namalengkap;
		$this->sppd->acc_SPPD($nosppd, $namahrd); //update status cuti menjadi "Dikonfirmasi"
		$this->session->set_flashdata('report', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h5 style="color:green;">Konfirmasi SPPD Sukses!!!</h5></div>');
		redirect('hrd_controller/sppdlist');

	}

	function history(){
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$data['listhistory'] = $this->cuti->get_all_listhistory();
		$this->load->view('admin_hrd/cuti/history.php',$data);
	}

	function resetcuti(){
		$date_now=date('d-m-Y');
		if($date_now>='05-01-'.date('Y')){
			$this->session->set_flashdata('disable_button', 'disabled');
		}
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/cuti/resetCuti.php', $data);
	}
	function do_resetcuti(){
		$this->pegawai->resetjatahcuti();
		$this->session->set_flashdata('report', '<br><div style="max-width:50%; text-align:center; margin-left:auto; margin-right:auto;"><font><h3 style="color:green;">Reset Sisa Cuti Sukses!</h3></div>');
		redirect ('hrd_controller/resetcuti');
	}


	function myhistory(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifcutiditerima']>0){
			$this->cuti->updatenotif();
			$data['notif']=$this->set_notification();			
		}
		$data['datauser']=$this->set_datauser();
		$data['listhistory'] = $this->cuti->get_listmyhistory($this->session->userdata('nik'));
		$this->load->view('admin_hrd/cutiku/myhistory.php',$data);
	}

	function sppdlist(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifsppd']>0){
			$this->sppd->updatepengajuansppd();
			$data['notif']=$this->set_notification();
		}
		$data['sppd']=$this->sppd->get_sppd();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/sppd/listsubmissionsppd.php', $data);	
	}

	function sppdhistory(){
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$data['sppd']=$this->sppd->get_all_listsppd();
		$this->load->view('admin_hrd/sppd/history.php', $data);	
	}

	function password(){
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/password/pass.php', $data);	
	}

	function registrasi(){
		$data['notif']=$this->set_notification();
		if($data['notif']['notifregistrasi']>0){
			$this->pendaftaran_pegawai->update_notifregistrasi();
			$data['notif']=$this->set_notification();
		}
		$data['kabid']=$this->pegawai->get_datakabid();
		$data['pendaftar']=$this->pendaftaran_pegawai->get_pendaftar();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/accregistrasi/listregistration.php', $data);
	}

	function administrator_master_status(){
		$data['status']=$this->daftar_status->get_daftarstatus();
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/administrator/master/master_status.php', $data);	
	}

	function administrator_master_pendidikan(){
		$data['pendidikan']=$this->daftar_dasarpenerimaan->get_daftardasarpenerimaan();
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/administrator/master/master_pendidikan.php', $data);	
	}

	function administrator_master_agama(){
		$data['agama']=$this->daftar_agama->get_daftaragama();
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/administrator/master/master_agama.php', $data);	
	}

	function administrator_master_bidang(){
		$data['bidang']=$this->daftar_bidang->get_daftarbidang();
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/administrator/master/master_bidang.php', $data);	
	}

	function cutikhusus(){
		$data['pegawai']=$this->pegawai->get_alluser();
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/cuti/specialsubmission.php', $data);	
	}

	function biodata(){
		$data['agama']=$this->daftar_agama->get_daftaragama();
		$data['notif']=$this->set_notification();
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/biodata.php', $data);
	}

	function keluarga(){
		$data['notif']=$this->set_notification();
		$data['datakeluarga']=$this->profil_keluarga->get_datakeluarga($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();

		$jumlahbaris = count($data['datakeluarga']);
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$tgllahir = $data['datakeluarga'][$i]['tgllahir'];
			$born_date	= new DateTime($tgllahir);
			$now 		= new DateTime('today');
			$usia= $born_date->diff($now)->y;
			$this->profil_keluarga->update_usia($usia, $this->session->userdata('nik'));
		}
		$data['datakeluarga']=$this->profil_keluarga->get_datakeluarga($this->session->userdata('nik'));
		
		$this->load->view('admin_hrd/profil/keluarga.php', $data);
	}

	function pendidikan(){
		$data['notif']=$this->set_notification();
		$data['pendidikan']= $this->profil_pendidikan->get_datapendidikan($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/pendidikan.php', $data);
	}

	function diklat(){
		$data['notif']=$this->set_notification();
		$data['diklat']= $this->profil_diklat->get_datadiklat($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/diklat.php', $data);
	}

	function karir(){
		$data['notif']=$this->set_notification();
		$data['jenjangkarir']=$this->profil_jenjangkarir->get_datajenjangkarir($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/karir.php', $data);
	}

	function pengalamankerja(){
		$data['notif']=$this->set_notification();
		$data['pengalamankerja']=$this->profil_pengalamankerja->get_datapengalamankerja($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/pengalamankerja.php', $data);
	}

	function prestasi(){
		$data['notif']=$this->set_notification();
		$data['prestasi']=$this->profil_prestasi->get_dataprestasi($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/prestasi.php', $data);
	}

	function organisasi(){
		$data['notif']=$this->set_notification();
		$data['organisasi']=$this->profil_organisasi->get_dataorganisasi($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/organisasi.php', $data);
	}

	function penghargaan(){
		$data['notif']=$this->set_notification();
		$data['penghargaan']=$this->profil_penghargaan->get_datapenghargaan($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/penghargaan.php', $data);
	}

	function sanksi(){
		$data['notif']=$this->set_notification();
		$data['sanksi']=$this->profil_sanksi->get_datasanksi($this->session->userdata('nik'));
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/sanksi.php', $data);
	}

	function prev(){
		$data['notif']=$this->set_notification();
		$data['biodata']=$this->profil_pegawai->get_biodata($this->session->userdata('nik'));
		$data['datakeluarga']=$this->profil_keluarga->get_datakeluarga($this->session->userdata('nik'));
		$data['pendidikan']= $this->profil_pendidikan->get_datapendidikan($this->session->userdata('nik'));
		$data['diklat']= $this->profil_diklat->get_datadiklat($this->session->userdata('nik'));
		$data['jenjangkarir']=$this->profil_jenjangkarir->get_datajenjangkarir($this->session->userdata('nik'));
		$data['pengalamankerja']=$this->profil_pengalamankerja->get_datapengalamankerja($this->session->userdata('nik'));
		$data['prestasi']=$this->profil_prestasi->get_dataprestasi($this->session->userdata('nik'));
		$data['organisasi']=$this->profil_organisasi->get_dataorganisasi($this->session->userdata('nik'));
		$data['penghargaan']=$this->profil_penghargaan->get_datapenghargaan($this->session->userdata('nik'));
		$data['sanksi']=$this->profil_sanksi->get_datasanksi($this->session->userdata('nik'));
		$data['datauser']=$this->set_datauser();
		$this->load->view('admin_hrd/profil/prevcetak.php', $data);
	}

	function pegawai(){
		$data['agama']=$this->daftar_agama->get_daftaragama();
		$data['bidang']=$this->daftar_bidang->get_daftarbidang();
		$data['status']=$this->daftar_status->get_daftarstatus();
		$data['dasarpenerimaan']=$this->daftar_dasarpenerimaan->get_daftardasarpenerimaan();

		$data['sanksi']=$this->profil_sanksi->get_alldatasanksi();		
		$data['penghargaan']=$this->profil_penghargaan->get_alldatapenghargaan();
		$data['prestasi']=$this->profil_prestasi->get_alldataprestasi();
		$data['organisasi']=$this->profil_organisasi->get_alldataorganisasi();
		$data['pengalamankerja']=$this->profil_pengalamankerja->get_alldatapengalamankerja();
		$data['diklat']= $this->profil_diklat->get_alldatadiklat();
		$data['jenjangkarir']=$this->profil_jenjangkarir->get_alldatajenjangkarir();
		$data['pendidikan']=$this->profil_pendidikan->get_alldatapendidikan();
		$data['keluarga']=$this->profil_keluarga->get_alldatakeluarga();
		$data['pegawai']=$this->pegawai->get_alluser();
		
		$data['notif']=$this->set_notification();
		$data['datauser']=$this->set_datauser();

		$jumlahbaris = count($data['keluarga']);
		for ($i=0; $i < $jumlahbaris ; $i++) {
			$nik = $data['keluarga'][$i]['nik'];
			$tgllahir = $data['keluarga'][$i]['tgllahir'];
			$born_date	= new DateTime($tgllahir);
			$now 		= new DateTime('today');
			$usia= $born_date->diff($now)->y;
			$this->profil_keluarga->update_usia($usia, $nik);
		}
		$data['keluarga']=$this->profil_keluarga->get_alldatakeluarga();
		$this->load->view('admin_hrd/administrator/pegawai/pegawai.php', $data);	
	}

	function do_deletestatus(){
		$nomor = $this->uri->segment(3);
		$this->daftar_status->delete_status($nomor);
		redirect('hrd_controller/administrator_master_status');
	}

	function do_addstatus(){
		$jumlahbaris=count($this->input->post('status'));
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data= array(
				'statuspegawai' => $this->input->post('status')[$i]
				 );
			$this->daftar_status->insert_status($data);
		}
		redirect('hrd_controller/administrator_master_status');
	}
	function do_deletependidikan(){
		$nomor = $this->uri->segment(3);
		$this->daftar_dasarpenerimaan->delete_pendidikan($nomor);
		redirect('hrd_controller/administrator_master_pendidikan');
	}
	function do_addpendidikan(){
		$jumlahbaris=count($this->input->post('pendidikan'));
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data= array(
				'pendidikan' => $this->input->post('pendidikan')[$i]
				 );
			$this->daftar_dasarpenerimaan->insert_pendidikan($data);
		}
		redirect('hrd_controller/administrator_master_pendidikan');
	}	
	function do_deleteagama(){
		$nomor = $this->uri->segment(3);
		$this->daftar_agama->delete_agama($nomor);
		redirect('hrd_controller/administrator_master_agama');
	}
	function do_addagama(){
		$jumlahbaris=count($this->input->post('agama'));
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data= array(
				'agama' => $this->input->post('agama')[$i]
				 );
			$this->daftar_agama->insert_agama($data);
		}
		redirect('hrd_controller/administrator_master_agama');
	}	

	function do_deletebidang(){
		$bidang = $this->uri->segment(3);
		$bidang = str_replace('%20', ' ', $bidang);
		$this->pegawai->update_bidangdefault($bidang);
		$this->daftar_bidang->delete_bidang($bidang);
		redirect('hrd_controller/administrator_master_bidang');
	}
	function do_addbidang(){
		$jumlahbaris=count($this->input->post('bidang'));
		for ($i=0; $i < $jumlahbaris ; $i++) { 
			$data= array(
				'bidang' => $this->input->post('bidang')[$i]
				 );
			$this->daftar_bidang->insert_bidang($data);
		}
		redirect('hrd_controller/administrator_master_bidang');
	}	
	
	function do_resetpassword(){
		$nik = $this->input->post('nik');
		$this->pegawai->reset_password($nik);
		redirect('hrd_controller/pegawai');
	}

	function do_changeaccess(){
		$nik = $this->input->post('nik');
		$role= $this->input->post('akses');
		$this->pegawai->changeaccess($nik, $role);
		redirect('hrd_controller/pegawai');
	}
	function do_deletaccount(){
		$nik = $this->input->post('nik');
		$this->pegawai->deleteaccount($nik);
		redirect('hrd_controller/pegawai');
	}

	function cetakcuti()
	{			
		$nocuti = $this->uri->segment(3);//mengambil nilai nomor cuti
		$data['data']= $this->cuti->get_infoprint($nocuti);
		$this->load->view('print/cetakcuti.php', $data);
	}
	function cetaksppd()
	{			
		$nosppd = $this->uri->segment(3);//mengambil nilai nomor cuti
		$data['data']= $this->sppd->get_infoprint($nosppd);
		$this->load->view('print/cetaksppd.php',$data);
	}
	function cetakBio(){
		$nik = $this->uri->segment(3);//mengambil nilai nomor cuti
		$data['sanksi']=$this->profil_sanksi->get_datasanksi($nik);		
		$data['penghargaan']=$this->profil_penghargaan->get_datapenghargaan($nik);
		$data['prestasi']=$this->profil_prestasi->get_dataprestasi($nik);
		$data['organisasi']=$this->profil_organisasi->get_dataorganisasi($nik);
		$data['pengalamankerja']=$this->profil_pengalamankerja->get_datapengalamankerja($nik);
		$data['diklat']= $this->profil_diklat->get_datadiklat($nik);
		$data['jenjangkarir']=$this->profil_jenjangkarir->get_datajenjangkarir($nik);
		$data['pendidikan']=$this->profil_pendidikan->get_datapendidikan($nik);
		$data['keluarga']=$this->profil_keluarga->get_datakeluarga($nik);
		$data['datauser']=$this->pegawai->get_data($nik);
		$this->load->view('print/biodata.php', $data);
	}
}

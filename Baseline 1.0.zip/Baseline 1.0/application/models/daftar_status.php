<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class daftar_status extends CI_Model {
	function get_daftarstatus(){
		$this->db->from('daftar_status');
		$this->db->order_by('statuspegawai','asc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function delete_status($no){
		$this->db->where('no', $no);
		$this->db->delete('daftar_status');
	}

	function insert_status($data){
		$this->db->insert('daftar_status',$data);
	}


}
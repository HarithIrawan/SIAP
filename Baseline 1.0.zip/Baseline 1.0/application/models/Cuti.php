<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cuti extends CI_Model {

	function cek_cuti($nik){
		$query = $this->db->get_where('cuti',array('nik' => $nik, 'status'=> 'Diajukan'));
		$numrows=$query->num_rows();
		return $numrows;
	}

	function cari_all_cuti($macamcuti){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('cuti.macamcuti', $macamcuti);
		$this->db->where('status', 'Dikonfirmasi');
		$this->db->order_by('nocuti', 'desc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function cari_kabid_cuti($macamcuti, $bidang){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('cuti.macamcuti', $macamcuti);
		$this->db->where('pegawai.bidang', $bidang);
		$this->db->where('status', 'Dikonfirmasi');
		$this->db->order_by('nocuti', 'desc');		
		$query = $this->db->get();
		return $query->result_array();
	}


	function insert_submission($data){
		$this->db->insert('cuti',$data);
	}	

	function update_submission($data,$nik){
		$this->db->where('nik', $nik);
		$this->db->update('cuti', $data);
	}

	function get_listsubmission($status, $bidang){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('cuti.status', $status);
		$this->db->where('pegawai.bidang', $bidang);
		$this->db->order_by('nocuti', 'desc');
		$query = $this->db->get();
		return $query->result_array();
	}
	function get_all_listsubmission($status){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('cuti.status', $status);
		$this->db->order_by('nocuti', 'desc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function acc_tahap1($nocuti,$namaadmin){
		$this->db->set('status','Diterima');
		$this->db->set('penyetujukabid', $namaadmin);		
		$this->db->set('terbaca', false);
		$this->db->where('nocuti', $nocuti);
		$this->db->update('cuti');
	}

	function acc_tahap2($nocuti, $namaadmin){
		$this->db->set('status','Dikonfirmasi');
		$this->db->set('penyetujuhrd', $namaadmin);		
		$this->db->set('terbaca', false);
		$this->db->where('nocuti', $nocuti);
		$this->db->update('cuti');
	}

	
	function decline($nocuti, $namaadmin){
		$this->db->set('status','Ditolak');
		$this->db->set('penyetujukabid', $namaadmin);		
		$this->db->set('penyetujuhrd', 'Admin HRD');		
		$this->db->set('terbaca', false);
		$this->db->where('nocuti', $nocuti);
		$this->db->update('cuti');
	}

	function get_tglkembali($nocuti)
	{
		$this->db->select('tglkembali');
		$this->db->from('cuti');
		$this->db->where('nocuti', $nocuti);
		$tglkembali=$this->db->get()->row();
		return $tglkembali->tglkembali;
	}

	function get_kabid_listhistory($bidang){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('pegawai.bidang', $bidang);
		$this->db->order_by('nocuti', 'desc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function get_all_listhistory(){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->order_by('nocuti', 'desc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function get_listmyhistory($nonik){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('pegawai.nik', $nonik);
		$this->db->order_by('nocuti', 'desc');
		$query = $this->db->get();
		return $query->result_array();
	}
	function get_notifcutidiajukan1($bidang){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('cuti.status', "Diajukan");
		$this->db->where('cuti.terbaca', false);
		$this->db->where('pegawai.bidang', $bidang);
		$query = $this->db->get();
		return $query->num_rows();
	}
	function get_notifcutidiajukan2(){
		$this->db->from('cuti');
		$this->db->where('status', "Diterima");
		$this->db->where('terbaca', false);
		$query = $this->db->get();
		return $query->num_rows();
	}
	function get_notifcutiditerima(){
		$where = "(status='Dikonfirmasi' OR status='Ditolak')AND terbaca=false";
		$this->db->from('cuti');
		$this->db->where($where);
		$this->db->where('nik', $this->session->userdata('nik'));		
		$query = $this->db->get();
		return $query->num_rows();		
	}

	function updatenotif(){
		$this->db->set('terbaca', true);
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->update('cuti');
	}

	function updatenotiftahap1(){
		$this->db->set('terbaca', true);
		$this->db->where('status', 'Diajukan');
		$this->db->update('cuti');
	}
	function updatenotiftahap2(){
		$this->db->set('terbaca', true);
		$this->db->where('status', 'Diterima');
		$this->db->update('cuti');
	}

	function get_infoprint($nocuti){
		$this->db->from('cuti');
		$this->db->join('pegawai', 'pegawai.nik = cuti.nik');
		$this->db->where('cuti.nocuti', $nocuti);
		$query = $this->db->get();
		return $query->result_array();
	}

	function update_nik($nik, $nikbaru){
		$this->db->set('nik', $nikbaru);
		$this->db->where('nik', $nik);
		$this->db->update('cuti');
	}


}
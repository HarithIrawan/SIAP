<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class profil_penghargaan extends CI_Model {

	function get_datapenghargaan($nik){
		$data = $this->db->where('nik', $nik);
		$data = $this->db->get('profil_penghargaan');
		return $data->result_array();
	}
	function insert_datapenghargaan($data){
		$this->db->insert('profil_penghargaan',$data);
	}

	function delete_datapenghargaan(){
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->delete('profil_penghargaan');
	}
	function get_alldatapenghargaan(){
		$this->db->from('profil_penghargaan');
		$this->db->join('pegawai', 'pegawai.nik=profil_penghargaan.nik');
		return $this->db->get()->result_array();
	}

	function update_nik($nik, $nikbaru){
		$this->db->set('nik', $nikbaru);
		$this->db->where('nik', $nik);
		$this->db->update('profil_penghargaan');
	}


}
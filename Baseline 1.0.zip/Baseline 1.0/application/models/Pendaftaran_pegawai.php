<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pendaftaran_pegawai extends CI_Model {

	function insert_pendaftaranpegawai($data){
		$this->db->insert('pendaftaran_pegawai',$data);
	}

	function cek_user($nik=""){
		$query = $this->db->get_where('pendaftaran_pegawai',array('nik' => $nik));
		$numrows=$query->num_rows();
		return $numrows;
	}

	function update_pendaftaranpegawai($data,$nik){
		$this->db->where('nik',$nik);
		$this->db->update('pendaftaran_pegawai',$data);
	}

	function get_pendaftar(){
		return $this->db->get('pendaftaran_pegawai')->result_array();
	}
	function get_spesificpendaftar($nik){
		return $this->db->get_where('pendaftaran_pegawai',array('nik' => $nik))->result_array();
	}

	function insert_pegawai($nik, $data, $data2){
		$this->db->trans_start();
		$this->db->trans_strict(TRUE);
		$this->db->insert('pegawai', $data);
		$this->db->insert('profil_pegawai', $data2);
		$this->db->query("DELETE FROM Pendaftaran_pegawai WHERE nik='".$nik."'");
		$this->db->trans_complete();		
	}
	function remove_pegawai($nik){
		$this->db->where('nik', $nik);
		$this->db->delete('pendaftaran_pegawai');
	}

	function get_notifpendaftaran(){
		$this->db->where('terbaca', false);
		return $this->db->get('pendaftaran_pegawai')->num_rows();
	}

	function update_notifregistrasi(){
		$this->db->set('terbaca', true);
		$this->db->update('pendaftaran_pegawai');
	}



}
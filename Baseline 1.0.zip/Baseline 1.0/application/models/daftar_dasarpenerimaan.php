<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class daftar_dasarpenerimaan extends CI_Model {
	function get_daftardasarpenerimaan(){
		$this->db->from('daftar_dasarpenerimaan');
		$this->db->order_by('pendidikan','asc');
		$query = $this->db->get();
		return $query->result_array();
	}
	function delete_pendidikan($no){
		$this->db->where('no', $no);
		$this->db->delete('daftar_dasarpenerimaan');
	}
	function insert_pendidikan($data){
		$this->db->insert('daftar_dasarpenerimaan',$data);
	}


}
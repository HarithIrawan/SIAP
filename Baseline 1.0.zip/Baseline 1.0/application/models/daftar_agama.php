<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class daftar_agama extends CI_Model {
	function get_daftaragama(){
		$this->db->from('daftar_agama');
		$this->db->order_by('agama','asc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function delete_agama($no){
		$this->db->where('no', $no);
		$this->db->delete('daftar_agama');
	}
	function insert_agama($data){
		$this->db->insert('daftar_agama',$data);
	}


}
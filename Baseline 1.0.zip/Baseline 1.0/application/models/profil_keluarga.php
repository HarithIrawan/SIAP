<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class profil_keluarga extends CI_Model {

	function get_datakeluarga(){
		$data = $this->db->where('nik', $this->session->userdata('nik'));
		$data = $this->db->get('profil_keluarga');
		return $data->result_array();
	}
	function insert_datakeluarga($data){
		$this->db->insert('profil_keluarga',$data);
	}

	function delete_datakeluarga(){
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->delete('profil_keluarga');
	}
	function update_nik($nik, $nikbaru){
		$this->db->set('nik', $nikbaru);
		$this->db->where('nik', $nik);
		$this->db->update('profil_keluarga');
	}

	function update_usia($usia, $nik){
		$this->db->set('usia', $usia);
		$this->db->where('nik', $nik);
		$this->db->update('profil_keluarga');
	}

	function get_alldatakeluarga(){
		return $this->db->get('profil_keluarga')->result_array();
	}
}
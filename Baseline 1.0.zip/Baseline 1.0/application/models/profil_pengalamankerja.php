<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class profil_pengalamankerja extends CI_Model {

	function get_datapengalamankerja($nik){
		$data = $this->db->where('nik', $nik);
		$data = $this->db->get('profil_pengalamankerja');
		return $data->result_array();
	}
	function insert_datapengalamankerja($data){
		$this->db->insert('profil_pengalamankerja',$data);
	}

	function delete_datapengalamankerja(){
		$this->db->where('nik', $this->session->userdata('nik'));
		$this->db->delete('profil_pengalamankerja');
	}

	function get_alldatapengalamankerja(){
		$this->db->from('profil_pengalamankerja');
		$this->db->join('pegawai', 'pegawai.nik=profil_pengalamankerja.nik');
		return $this->db->get()->result_array();
	}

	function update_nik($nik, $nikbaru){
		$this->db->set('nik', $nikbaru);
		$this->db->where('nik', $nik);
		$this->db->update('profil_pengalamankerja');
	}


}
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class daftar_bidang extends CI_Model {
	function get_daftarbidang(){
		$this->db->from('daftar_bidang');
		$this->db->order_by('bidang','asc');
		$query = $this->db->get();
		return $query->result_array();
	}

	function delete_bidang($bidang){
		$this->db->where('bidang', $bidang);
		$this->db->delete('daftar_bidang');
	}
	function insert_bidang($data){
		$this->db->insert('daftar_bidang',$data);
	}


}
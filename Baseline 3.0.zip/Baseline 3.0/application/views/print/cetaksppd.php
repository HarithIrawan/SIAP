<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style type="text/css">
      @page{
        margin: 15mm 15mm 15mm 15mm;
      }
    </style>

    <title>Form SPPD</title>
  </head>
  <body onload="print()">
    <div class="container">
      <div class="row">
        <div class="col-sm-12" style="height: 50px;">
          
        </div>
        <div class="col-sm-2">
          <div class="text-center">
            <img src="<?php echo base_url('assets/dist/img/petrokopindo.png');?>" class="img-fluid" alt="Responsive image">
          </div>
        </div>
        <div class="col-sm-8" style="text-align: center; padding: 1%;">
          <h1><b>PT PETROKOPINDO CIPTA SELARAS</b></h1>
        </div>
        <div class="col-sm-2">
          
        </div>
        <div class="col-sm-12">
          <br>
          <h4 style="text-align: center;">SURAT PERINTAH PERJALANAN DINAS (SPPD)</h4>
          <hr style="width: 510px;">
          <br>
        </div>
        <div class="col-sm-12">
          <p>Diperintahkan untuk melaksanakan tugas perjalanan dinas dengan penuh rasa tanggung jawab kepada :</p>
          <table class="table table-borderless">
            <tbody>
              <tr>
                <td>Nama</td>
                <td><?=$data[0]['namalengkap']?></td>
              </tr>
              <tr>
                <td>NIK</td>
                <td><?=$data[0]['nik']?></td>
              </tr>
              <tr>
                <td>Bidang</td>
                <td><?=$data[0]['bidang']?></td>
              </tr>
              <tr>
                <td>Tujuan</td>
                <td><?=$data[0]['tujuanperjalanan']?></td>
              </tr>
              <tr>
                <td>Pengikut</td>
                <td><?=$data[0]['pegawai']?></td>
              </tr>
              <tr>
                <td>Tanggal Berangkat</td>
                <td><?= date("d-m-Y",strtotime($data[0]['tglberangkat']))?></td>
              </tr>
              <tr>
                <td>Tanggal Kembali</td>
                <td><?= date("d-m-Y",strtotime($data[0]['tglkembali']))?></td>
              </tr>
              <tr>
                <td>Lama Perjalanan</td>
                <td><?=$data[0]['lamahari']." Hari"?></td>
              </tr>
              <tr>
                <td>Tugas yang dilakukan</td>
                <td><?=$data[0]['maksudperjalanan']?></td>
              </tr>
            </tbody>
          </table>
          <br>
          <br>
        </div>
        <div class="col-sm-12">
          <p>Setelah selesai / kembali ditempat kerja, segera melapor dan / atau membuat laporan kepada atasan yang menugaskan dan menyelesaikan pertanggungjawaban kasbon</p>
          <p style="text-align: right;">Gresik, 3 Juli 2018</p>
          <br>
        </div>
        <div class="col-sm-12" style="text-align: center;">
          <div class="row">
            <div class="col-sm-4">
              Yang diperintahkan,
              <br>
              <br>
              <span class="badge badge-success">Disetujui</span>
              <br>
              <br>
              <?=$data[0]['pegawai']?>
              <br>
              SDM DAN UMUM
            </div>
            <div class="col-sm-4">
              Yang memerintah,
              <br>
              <br>
              <span class="badge badge-success">Disetujui</span>
              <br>
              <br>
              <?=$data[0]['penyetujukabid']?>
              <br>
              Kabid. <?=$data[0]['bidang']?>
            </div>
            <div class="col-sm-4">
              Menyetujui
              <br>
              <br>
              <span class="badge badge-success dikonfirmasi">Disetujui</span>
              <br>
              <br>
              <?=$data[0]['penyetujuhrd']?>
              <br>
              SDM DAN UMUM
            </div>
          </div>
        </div>
      </div>
    </div>
    <br>    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script type="text/JavaScript">
      if("<?=$data[0]['status']?>"=="Diajukan"){
        $('.dikonfirmasi').css('display', 'none');
      }
    </script>
  </body>
</html>
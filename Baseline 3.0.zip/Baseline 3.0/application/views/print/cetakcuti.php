<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style type="text/css">
      @page{
        margin: 15mm 15mm 15mm 15mm;
      }
    </style>

    <title>Form Cuti</title>
  </head>
  <body onload="printpage()">
    <br>
    <br>
    <br>
    <div class="container">
      <div class="row">
        <div class="col-sm-2">
          <div class="text-center">
            <img src="<?php echo base_url('assets/dist/img/petrokopindo.png');?>" class="img-fluid" alt="Responsive image">
          </div>
        </div>
        <div class="col-sm-8" style="text-align: center; padding: 3%;">
          <h1><b>PT PETROKOPINDO CIPTA SELARAS</b></h1>
        </div>
        <div class="col-sm-2">
          
        </div>
        <div class="col-sm-12">
          <br>
          <p>Saya yang bertanda tangan di bawah ini :</p>
          <table class="table table-borderless">
            <tbody>
              <tr>
                <td>NIK / Nama</td>
                <td>: <?= $data[0]['nik'].' / '.$data[0]['namalengkap'] ?></td>
              </tr>
              <tr>
                <td>Bidang</td>
                <td>: <?= $data[0]['bidang'] ?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="col-sm-6">
          <table class="table table-borderless">
            <tbody>
              <tr>
                <td>Dengan ini mengajukan permohonan untuk</td>
                <td>: <b>CUTI</b></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="col-sm-12">
          <table class="table table-borderless">
            <tbody>
              <tr>
                <td>Pada</td>
                <td>: <?= date("d-m-Y", strtotime($data[0]['tglmulai'])).' s/d '.date("d-m-Y", strtotime($data[0]['tglkembali']))?></td>
              </tr>
              <tr>
                <td>Selama</td>
                <td><?=$data[0]['lamacuti'].' Hari'?></td>
              </tr>
              <tr>
                <td>Tanggal Kembali</td>
                <td><?php 
                $tglkembali   = new DateTime($data[0]['tglkembali']);
                $tglkembali   = date_add($tglkembali, date_interval_create_from_date_string('1 days'));
                $tglkembali  = $tglkembali->format('d-m-Y');
                echo $tglkembali;?></td>
              </tr>
              <tr>
                <td>Macam Cuti</td>
                <td><?=$data[0]['macamcuti']?></td>
              </tr>
              <tr>
                <td>Outstanding Tugas</td>
                <td><?=$data[0]['outstandingtugas']?></td>
              </tr>
              <tr>
                <td>Petugas Pengganti</td>
                <td><?=$data[0]['petugaspengganti']?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="col-sm-12">
          <p>Demikian permohonan cuti ini saya ajukan untuk mendapatkan persetujuan</p>
          <p style="text-align: right;">Gresik, 14 Juli 2018</p>
          <br>
        </div>
        <div class="col-sm-12" style="text-align: center;">
          <div class="row">
            <div class="col-sm-3">
              Karyawan
              <br>
              <br>
              <span class="badge badge-success">Disetujui</span>
              <br>
              <br>
              <?=$data[0]['namalengkap']?>
              <br>
              <?=$data[0]['bidang']?>
            </div>
            <div class="col-sm-3">
              Petugas Pengganti
              <br>
              <br>
              <span class="badge badge-success">Disetujui</span>
              <br>
              <br>
              <?=$data[0]['petugaspengganti']?>
              <br>
              <?=$data[0]['bidang']?>
            </div>
            <div class="col-sm-3">
              Menyetujui
              <br>
              <br>
              <span class="badge badge-success diterima">Disetujui</span>
              <span class="badge badge-danger ditolak">Ditolak</span>
              <br>
              <br>
              <?=$data[0]['penyetujukabid']?>
              <br>
              KEPALA <?=$data[0]['bidang']?>
            </div>
            <div class="col-sm-3">
              Mengetahui
              <br>
              <br>
              <span class="badge badge-success dikonfirmasi">Disetujui</span>
              <span class="badge badge-danger ditolak">Ditolak</span>
              <br>
              <br>
              <?=$data[0]['penyetujuhrd']?>
              <br>
              MENGETAHUI <?=$data[0]['bidang']?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <br>
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script type="text/javascript">
      function printpage(){
        var i = "<?=$data[0]['status']?>";
        if(i=="Diterima"){
          $('.dikonfirmasi').css('display','none');
          $('.ditolak').css('display','none');
          print();
        }else if(i=="Dikonfirmasi"){
          $('.ditolak').css('display','none');
          print();
        }else if(i=="Ditolak"){
          $('.diterima').css('display','none');
          $('.dikonfirmasi').css('display','none');
          print();
        }else if(i=="Diajukan"){
          $('.ditolak').css('display','none');
          $('.diterima').css('display','none');
          $('.dikonfirmasi').css('display','none');
          print();
        }
      }
    </script>
  </body>
</html>

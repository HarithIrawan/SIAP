<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <style type="text/css">
      @page{
        margin: 30px;
      }
    </style>

    <title>Form Biodata</title>
  </head>
  <body onload="window.print()">
    <div class="container">
      <div class="row">
        <div class="col-sm-2">
          <div class="text-center">
            <img src="<?php echo base_url('assets/dist/img/petrokopindo.png');?>" class="img-fluid" alt="Responsive image">
          </div>
        </div>
        <div class="col-sm-8" style="text-align: center; padding: 3%;">
          <h1><b>PT PETROKOPINDO CIPTA SELARAS</b></h1>
        </div>
        <div class="col-sm-2">
          
        </div>
        <div class="col-sm-12">
          <hr>
          <br>
          <table class="table table-bordered break">
            <tbody>
              <tr>
                <td>NIK</td>
                <td><?=$datauser[0]['nik']?></td>
              </tr>
              <tr>
                <td>Nama Lengkap & Gelar</td>
                <td><?=$datauser[0]['namalengkap']?></td>
              </tr>
              <tr>
                <td>Nama Panggilan</td>
                <td><?=$datauser[0]['namapanggilan']?></td>
              </tr>
              <tr>
                <td>Tgl. Lahir</td>
                <td><?=date("d-m-Y",strtotime($datauser[0]['tgllahir'])) ?></td>
              </tr>
              <tr>
                <td>Tgl. Masuk Kerja</td>
                <td><?=date("d-m-Y",strtotime($datauser[0]['tglmasuk'])) ?></td>
              </tr>
              <tr style="color: red;">
                <td>Tgl. Pensiun</td>
                <td><?=$datauser[0]['tglpensiun']?></td>
              </tr>
              <tr>
                <td>Status Pegawai</td>
                <td><?=$datauser[0]['nik']?></td>
              </tr>
              <tr>
                <td>Bidang</td>
                <td><?=$datauser[0]['bidang']?></td>
              </tr>
              <tr>
                <td>Jenis Kelamin</td>
                <td><?=$datauser[0]['jeniskelamin']?></td>
              </tr>
              <tr>
                <td>Dasar Penerimaan</td>
                <td><?=$datauser[0]['dasarpenerimaan']?></td>
              </tr>
              <tr>
                <td>Agama</td>
                <td><?=$datauser[0]['agama']?></td>
              </tr>
              <tr>
                <td>Suku Bangsa</td>
                <td><?=$datauser[0]['sukubangsa']?></td>
              </tr>
              <tr>
                <td>Golongan Darah</td>
                <td><?=$datauser[0]['golongandarah']?></td>
              </tr>
              <tr>
                <td>Tinggi Badan</td>
                <td><?=$datauser[0]['tinggibadan']?></td>
              </tr>
              <tr>
                <td>Berat Badan</td>
                <td><?=$datauser[0]['beratbadan']?></td>
              </tr>
              <tr>
                <td>Hobi</td>
                <td><?=$datauser[0]['hobi']?></td>
              </tr>
              <tr>
                <td>Motto Hidup</td>
                <td><?=$datauser[0]['mottohidup']?></td>
              </tr>
              <tr>
                <td>No. KTP</td>
                <td><?=$datauser[0]['noktp']?></td>
              </tr>
              <tr>
                <td>Alamat Sesuai KTP</td>
                <td><?=$datauser[0]['alamatktp']?></td>
              </tr>
              <tr>
                <td>Alamat Sekarang</td>
                <td><?=$datauser[0]['alamatsekarang']?></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><?=$datauser[0]['email']?></td>
              </tr>
              <tr>
                <td>Status</td>
                <td><?=$datauser[0]['status']?></td>
              </tr>
              <tr>
                <td>No. KK</td>
                <td><?=$datauser[0]['nokk']?></td>
              </tr>
              <tr>
                <td>No. BPJS</td>
                <td><?=$datauser[0]['bpjs']?></td>
              </tr>
              <tr>
                <td>No. Sepatu</td>
                <td><?=$datauser[0]['nosepatu']?></td>
              </tr>
              <tr>
                <td>Ukuran Seragam</td>
                <td><?=$datauser[0]['ukuranseragam']?></td>
              </tr>
              <tr>
                <td>Nama Ibu Kandung</td>
                <td><?=$datauser[0]['namaibukandung']?></td>
              </tr>
              <tr>
                <td>Nama Ayah Kandung</td>
                <td><?=$datauser[0]['namaayahkandung']?></td>
              </tr>
              <tr>
                <td>Keahlian Khusus</td>
                <td><?=$datauser[0]['keahliankhusus']?></td>
              </tr>
              <tr>
                <td>Bahasa Yang Dikuasai</td>
                <td><?=$datauser[0]['bahasadikuasai']?></td>
              </tr>
              <tr>
                <td>Hasil Medical Checkup</td>
                <td><?=$datauser[0]['hasilmedical']?></td>
              </tr>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Keluarga</label>
            <thead>
              <tr>
                <th>Status</th>
                <th>Nama</th>
                <th>Tgl. Lahir</th>
                <th>Usia</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($keluarga as $data): ?>
                <tr>
                  <td><?=$data['status']?></td>
                  <td><?=$data['nama']?></td>
                  <td><?=$data['tgllahir']?></td>
                  <td><?=$data['Usia']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Pendidikan</label>
            <thead>
              <tr>
                <th>Jenis</th>
                <th>Keterangan</th>
                <th>Jurusan</th>
                <th>Thn. Lulus</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($pendidikan as $data): ?>
                <tr>
                  <td><?=$data['jenis']?></td>
                  <td><?=$data['keterangan']?></td>
                  <td><?=$data['jurusan']?></td>
                  <td><?=$data['thnlulus']?></td>
                </tr>                                      
              <?php endforeach ?>

            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Diklat</label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Nama Diklat</th>
                <th>Tahun</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($diklat as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['namadiklat']?></td>
                  <td><?=$data['tahun']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Jenjang Karir</label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Jabatan</th>
                <th>Tgl. SK</th>
                <th>No. SK</th>
                <th>Berakhir SK</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($jenjangkarir as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['jabatan']?></td>
                  <td><?=$data['tglsk']?></td>
                  <td><?=$data['nosk']?></td>
                  <td><?=$data['berakhirsk']?></td>
                  <td><?=$data['keterangan']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Pengalaman Kerja</label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Pengalaman Kerja</th>
                <th>Tahun</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($pengalamankerja as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['pengalamankerja']?></td>
                  <td><?=$data['tahun']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="Organisasi"></label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Organisasi</th>
                <th>Tahun</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($organisasi as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['organisasi']?></td>
                  <td><?=$data['tahun']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Prestasi</label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Prestasi</th>
                <th>Tahun</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($prestasi as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['prestasi']?></td>
                  <td><?=$data['tahun']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Penghargaan</label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Penghargaan</th>
                <th>Tahun</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($penghargaan as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['penghargaan']?></td>
                  <td><?=$data['tahun']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
        <div class="col-sm-12">
          <table class="table table-bordered">
            <label for="">Sanksi</label>
            <thead>
              <tr>
                <th>No.</th>
                <th>Tgl. Sanksi</th>
                <th>Keterangan</th>
                <th>Berakhir</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php $i=0; 
              foreach ($sanksi as $data): ?>
                <tr>
                  <td><?=++$i?></td>
                  <td><?=$data['tglsanksi']?></td>
                  <td><?=$data['keterangan']?></td>
                  <td><?=$data['berakhir']?></td>
                  <td><?=$data['status']?></td>
                </tr>                                      
              <?php endforeach ?>
            </tbody>
          </table>
          <br>
          <hr>
          <br>
        </div>
      </div>
    </div>
    <br>
    <!-- <center>
      <button type="button" class="btn btn-primary" id="printButton" onclick="printPage()">Print</button>  
    </center> -->
    
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script type="text/JavaScript">
      function printPage(){
        printButton.style.visibility = 'hidden;'
        window.print();
        printButton.style.visibility = 'visible';
      }
    </script>
  </body>
</html>
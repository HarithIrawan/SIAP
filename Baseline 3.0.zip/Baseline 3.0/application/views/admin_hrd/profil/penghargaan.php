<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>HRIS PT Petrokopindo Cipta Selaras</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/skins/_all-skins.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.css">

  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/dist/Datatable/datatables.min.css"/>
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/overlay.css">

  <style type="text/css">
    input{
       background-color: transparent;
       border: hidden;
       text-align: center;
     }
  </style>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue fixed sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="<?=base_url('index.php/hrd_controller/index')?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b>ris</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>H</b>ris</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']);?>"class="user-image" alt="User Image" />
              <span class="hidden-xs"><?php echo $datauser['datauser'][0]['namalengkap']?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']); ?>"class="img-circle" alt="User Image" />
                <p>
                  <?php echo $datauser['datauser'][0]['namalengkap']?>
                  <small>Pegawai sejak <?php echo date("d-m-Y",strtotime($datauser['datauser'][0]['tglmasuk']))?></small>
                </p>
              </li>
              <!-- Menu Body -->
              
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?=base_url('index.php/hrd_controller/biodata')?>" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?=base_url('index.php/logout_controller')?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']); ?>"class="img-circle" alt="User Image" style="width: 40px; height: 40px">
        </div>
        <div class="pull-left info">
          <p><?php echo $datauser['datauser'][0]['namalengkap'] ?> </p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/index')?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="active">
          <a href="<?=base_url('index.php/hrd_controller/biodata')?>">
            <i class="fa fa-user"></i> <span>Profile</span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i> <span>Cuti-Ku</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"><?php echo $notif['notifcutiditerima'] ?></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url('index.php/hrd_controller/submission')?>">Pengajuan</a></li>
            <li><a href="<?=base_url('index.php/hrd_controller/myhistory')?>">Riwayat
              <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo $notif['notifcutiditerima'] ?></span>
                </span>
              </a>
            </li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i> <span>Cuti Pegawai</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"><?php echo $notif['notifcutitahap2'] ?></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url('index.php/hrd_controller/cutikhusus')?>">Pengajuan Cuti Khusus</a></li>
            <li><a href="<?=base_url('index.php/hrd_controller/listsubmission')?>">Daftar Pengajuan
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo $notif['notifcutitahap2'] ?></span>
                </span>
              </a>
            </li>
            <li><a href="<?=base_url('index.php/hrd_controller/history')?>">Riwayat</a></li>
            <li><a href="<?=base_url('index.php/hrd_controller/resetCuti')?>">Reset Cuti</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i> <span>SPPD</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"><?php echo $notif['notifsppd'] ?></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url('index.php/hrd_controller/sppdlist')?>">Daftar Pengajuan
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo $notif['notifsppd'] ?></span>
                </span>
              </a>
            </li>
            <li><a href="<?=base_url('index.php/hrd_controller/sppdhistory')?>">Riwayat</a></li>
          </ul>
        </li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/registrasi')?>">
            <i class="fa fa-envelope-o"></i> <span>Registrasi</span>
            <span class="label label-warning pull-right"><?php echo $notif['notifregistrasi'] ?></span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope-o"></i> <span>Administrator</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?=base_url('index.php/hrd_controller/administrator_master_status')?>">Master</a>
            </li>
            <li>
              <a href="<?=base_url('index.php/hrd_controller/pegawai')?>">Pegawai</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/password')?>">
            <i class="fa fa-key"></i> <span>Ganti Password</span> 
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Profile
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=base_url('index.php/hrd_controller/index')?>"> Home</a></li>
        <li><a href="<?=base_url('index.php/hrd_controller/biodata')?>">Profile</a></li>
        <li class="active">Penghargaan</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3" style="padding-top: 20px; padding-bottom: 10px;">
          <div class="info">
            <center>
              <div class="container">
              <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']);?>"class="img-circle image" style="border: 5px solid #666; width: 150px; height: 150px; display: block;" alt="User Image">
              </div>

              <br>
              <h4><?php echo $datauser['datauser'][0]['namalengkap'] ?></h4>
              <h5><?php echo $datauser['datauser'][0]['bidang'] ?></h5>
              <br>
            </center>  
          </div>
          <div class="about text-center">
            <h3>About</h3>
          </div>
          <p style="text-align: center;"><?php echo $biodata[0]['mottohidup'] ?></p>
        </div>
        <div class="col-md-9">
          <nav class="navbar navbar-default">
            <div class="container-fluid">
              <!-- Brand and toggle get grouped for better mobile display -->
              <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?=base_url('index.php/hrd_controller/biodata')?>">Home</a>
              </div>

              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Profil <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="<?=base_url('index.php/hrd_controller/biodata')?>" class="page-scroll">Pribadi</a></li>
                      <li><a href="<?=base_url('index.php/hrd_controller/keluarga')?>" class="page-scroll">Keluarga</a></li>
                    </ul>
                  </li>
                  <li><a href="<?=base_url('index.php/hrd_controller/pendidikan')?>" class="page-scroll">Pendidikan</a></li>
                  <li><a href="<?=base_url('index.php/hrd_controller/diklat')?>" class="page-scroll">Diklat</a></li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Karir <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="<?=base_url('index.php/hrd_controller/karir')?>" class="page-scroll">Jenjang Karir</a></li>
                      <li><a href="<?=base_url('index.php/hrd_controller/pengalamankerja')?>" class="page-scroll">Pengalaman Kerja</a></li>
                    </ul>
                  </li>
                  <li><a href="#organisasi" class="page-scroll" id="organisasi">Organisasi</a></li>
                  <li class="dropdown active">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Award <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                      <li><a href="<?=base_url('index.php/hrd_controller/prestasi')?>" class="page-scroll">Prestasi</a></li>
                      <li class="active"><a href="#" id="penghargaan" class="page-scroll">Penghargaan</a></li>
                    </ul>
                  </li>
                  <li><a href="<?=base_url('index.php/hrd_controller/sanksi')?>" class="page-scroll">Sanksi</a></li>
                  <li><a href="<?=base_url('index.php/hrd_controller/prev')?>" class="page-scroll">Prev / Cetak</a></li>
                </ul>
              </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
          </nav>
        </div>
        <div class="col-md-1 col-md-offset-8" style="margin-top: -10px; margin-bottom: 10px;">
          <button id="edit" onclick="edit()">
            <i class="fa fa-edit" style="font-size: 30px;"></i>
          </button>
        </div>
        <div class="col-md-9">
          <div class="box box-info">
              <div class="box-body" style="overflow-x: auto;">
                <form action="<?=base_url('index.php/hrd_controller/do_updateprofilpenghargaan')?>" method="post" id="formpenghargaan">
                  <table id="tabelpenghargaan" class="table table-bordered table-hover text-center">
                    <thead>
                    <tr>
                      <th>NO.</th>
                      <th>PENGHARGAAN</th>
                      <th>TAHUN</th>
                      <th style="display: none" class="sembunyi">AKSI</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $i=0;
                    foreach ($penghargaan as $data ):?>
                      <tr>
                        <td><?php echo ++$i?></td>
                        <td><input type="text" name="penghargaan[]" value="<?php echo $data['penghargaan'] ?>" readonly></td>
                        <td><input type="number" name="tahun[]" value="<?php echo $data['tahun'] ?>" readonly></td>
                        <td class="sembunyi" style="display: none"><input class="btn btn-primary btn-xs" type="button" value="Hapus"></td>
                      </tr>
                      <?php endforeach ?>
                    </tbody>
                </table>
                </form>
              <p>
                <input type="button" class="btn btn-primary" id="tambah" style="float: right; margin-top: 10px; visibility: hidden;" value="Tambah">
              </p>
              </div>
          </div>          
        </div>
        <!-- /.col -->
        <div class="col-md-3">
          
        </div>
        <div class="col-md-9">
          <center>
            <button form="formpenghargaan" type="submit" class="btn btn-primary" style="visibility: hidden;" id="simpan">Simpan</button>      
          </center>
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2018-2019 <a href="#">Ganteng's Team</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url();?>assets/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url();?>assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

<script src="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url();?>assets/bower_components/moment/min/moment.min.js"></script>

<script src="<?php echo base_url();?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url();?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url();?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url();?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url();?>assets/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/dist/js/demo.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/dist/Datatable/datatables.min.js"></script>

<script type="text/javascript">
  function edit(){
    $('.sembunyi').show();

    document.getElementById("edit").style.visibility = 'hidden';
    document.getElementById("simpan").style.visibility = 'visible';
    document.getElementById("tambah").style.visibility = 'visible';

    $('input[type="text"], input[type="number"]').prop("readonly", false);
    $('input[type="text"], input[type="number"]').css({
      border: "1px black solid"
    });

    $('#tabelpenghargaan').on('click', 'input[type="button"]', function () {
    $(this).closest('tr').remove();
    })

    $('p input[type="button"]').click(function () {
    $('#tabelpenghargaan').append('<tr><td> - </td><td><input style="border: 1px solid black" type="text" name="penghargaan[]" value=""></td><td><input style="border: 1px solid black" type="number" name="tahun[]" value=""></td><td><input class="btn btn-primary btn-xs" type="button" value="Hapus"></td></tr>')
  });
  }
</script>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>HRIS PT Petrokopindo Cipta Selaras</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/dist/css/skins/_all-skins.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.css">

  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/dist/Datatable/datatables.min.css"/>

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>
<body class="hold-transition skin-blue fixed sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="<?=base_url('index.php/hrd_controller/index')?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>H</b>ris</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>H</b>ris</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']); ?>" class="user-image" alt="User Image">
              <span class="hidden-xs">
                <?php echo $datauser['datauser'][0]['namalengkap'] ?>
              </span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']); ?>" class="img-circle" alt="User Image">
                <p>
                  <?php echo $datauser['datauser'][0]['namalengkap']?>
                  <small>Pegawai sejak <?php echo date("d-m-Y",strtotime($datauser['datauser'][0]['tglmasuk']))?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="<?=base_url('index.php/hrd_controller/biodata')?>" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="<?=base_url('index.php/logout_controller')?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo base_url('assets/uploads/'.$datauser['namafoto']); ?>" class="img-circle" alt="User Image" style="width: 40px; height: 40px;">
        </div>
        <div class="pull-left info">
          <p> <?php echo $datauser['datauser'][0]['namalengkap'] ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/index')?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/biodata')?>">
            <i class="fa fa-user"></i> <span>Profile</span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i> <span>Cuti-Ku</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"><?php echo $notif['notifcutiditerima'] ?></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url('index.php/hrd_controller/submission')?>">Pengajuan</a></li>
            <li><a href="<?=base_url('index.php/hrd_controller/myhistory')?>">Riwayat
              <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo $notif['notifcutiditerima'] ?></span>
                </span>
              </a>
            </li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i> <span>Cuti Pegawai</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"><?php echo $notif['notifcutitahap2'] ?></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url('index.php/hrd_controller/cutikhusus')?>">Pengajuan Cuti Khusus</a></li>
            <li><a href="<?=base_url('index.php/hrd_controller/listsubmission')?>">Daftar Pengajuan
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo $notif['notifcutitahap2'] ?></span>
                </span>
              </a>
            </li>
            <li><a href="<?=base_url('index.php/hrd_controller/history')?>">Riwayat</a></li>
            <li><a href="<?=base_url('index.php/hrd_controller/resetCuti')?>">Reset Cuti</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i> <span>SPPD</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"><?php echo $notif['notifsppd'] ?></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url('index.php/hrd_controller/sppdlist')?>">Daftar Pengajuan
                <span class="pull-right-container">
                  <span class="label label-warning pull-right"><?php echo $notif['notifsppd'] ?></span>
                </span>
              </a>
            </li>
            <li><a href="<?=base_url('index.php/hrd_controller/sppdhistory')?>">Riwayat</a></li>
          </ul>
        </li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/registrasi')?>">
            <i class="fa fa-envelope-o"></i> <span>Registrasi</span>
            <span class="label label-warning pull-right"><?php echo $notif['notifregistrasi'] ?></span>
          </a>
        </li>
        <li class="treeview active">
          <a href="#">
            <i class="fa fa-envelope-o"></i> <span>Administrator</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
              <span class="label label-warning pull-right"></span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li>
              <a href="<?=base_url('index.php/hrd_controller/administrator_master_status')?>">Master</a>
            </li>
            <li class="active">
              <a href="<?=base_url('index.php/hrd_controller/pegawai')?>">Pegawai</a>
            </li>
          </ul>
        </li>
        <li>
          <a href="<?=base_url('index.php/hrd_controller/password')?>">
            <i class="fa fa-key"></i> <span>Ganti Password</span> 
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Pegawai
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?=base_url('index.php/hrd_controller/index')?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="<?=base_url('index.php/hrd_controller/pegawai')?>">Administrator</a></li>
        <li><a href="#">Pegawai</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-12">
          <div class="box box-info" style="overflow-x: auto; padding: 10px;">
            <table id="pegawai" class="table table-bordered table-hover">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>NIK</th>
                  <th>Nama</th>
                  <th>Bidang</th>
                  <th>Status</th>
                  <th>-</th>
                  <th>-</th>
                  <th>-</th>
                  <th>-</th>
                </tr>
              </thead>
              <tbody>
                  <?php 
                  $nomor=0;
                  foreach ($pegawai as $rows): ?>
                  <tr>
                    <td><?=++$nomor; ?></td>
                    <td><?=$rows['nik']?></td>
                    <td><?=$rows['namalengkap']?></td>
                    <td><?=$rows['bidang']?></td>
                    <td><?=$rows['statuspegawai']?></td>
                    <td><a href="#gantiPass<?=$rows['nik']?>" data-toggle="modal"><i class="fa fa-key"></i></a>
                      <div id="gantiPass<?=$rows['nik']?>" class="modal fade gantiPass" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                        <div class="modal-dialog modal-sm" role="document">
                          <div class="modal-content" style="margin-top: 80%; margin-bottom: 80%;">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title">Ganti Password</h4>
                            </div>
                            <div class="modal-body">
                              <label>Anda yakin ingin mereset password?</label>
                            </div>
                            <div class="modal-footer">
                              <form action="<?=base_url('index.php/hrd_controller/do_resetpassword')?>" method="post">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Tidak</button>
                                <button type="submit" name="nik" value="<?=$rows['nik']?>" class="btn btn-primary"><i class="fa fa-save"></i> Ya</button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td><a href="#biodata<?=$rows['nik']?>" data-toggle="modal"><i class="fa fa-edit"></i></a>

                    <div id="biodata<?=$rows['nik']?>" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                      <div class="modal-dialog modal-lg" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title">Biodata Pegawai</h4>
                          </div>
                          <form action="<?=base_url('index.php/hrd_controller/edit_profilepegawai/'.$rows['nik'])?>" method="post">
                          <div class="modal-body">
                            <section class="profil">
                              <div class="form-group has-feedback">
                                <label>NIK</label>
                                <input type="text" class="form-control" name="nik" value="<?=$rows['nik']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Nama Lengkap</label>
                                <input type="text" class="form-control" name="namalengkap" value="<?=$rows['namalengkap']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Nama Panggilan</label>
                                <input type="text" class="form-control" name="namapanggilan" value="<?=$rows['namapanggilan']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Tanggal Lahir</label>
                                <input type="date" class="form-control" name="tgllahir" value="<?=date("Y-m-d",strtotime($rows['tgllahir'])) ?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Tanggal Masuk Kerja</label>
                                <input type="date" class="form-control" name="tglmasuk" value="<?=date("Y-m-d",strtotime($rows['tglmasuk'])) ?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Tanggal Pensiun</label>
                                <input type="text" class="form-control" name="tglpensiun" value="<?=$rows['tglpensiun']?>"readonly>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Status Pegawai</label>

                                <select class="form-control" name="statuspegawai">
                                  <option value=""<?php if($rows['statuspegawai']=="") echo "selected"?> disabled></option>
                                  <?php foreach ($status as $data): ?>
                                    <option value="<?=$data['statuspegawai']?>"<?php if($data['statuspegawai']==$rows['statuspegawai']) echo "selected"?>><?=$data['statuspegawai']?></option>
                                  <?php endforeach ?>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Bidang Kerja</label>
                                <select class="form-control" name="bidang">
                                  <option value=""<?php if($rows['bidang']=="") echo "selected"?> disabled></option>
                                  <?php foreach ($bidang as $data): ?>
                                    <option value="<?=$data['bidang']?>"<?php if($data['bidang']==$rows['bidang']) echo "selected"?>><?=$data['bidang']?></option>
                                  <?php endforeach ?>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Jenis Kelamin</label>
                                <select class="form-control" name="kelamin">
                                  <option value=""<?php if($rows['jeniskelamin']=="") echo "selected"?> disabled></option>
                                  <option value="Laki-laki"<?php if($rows['jeniskelamin']=="Laki-Laki") echo "selected"?>>Laki-laki</option>
                                  <option value="Perempuan"<?php if($rows['jeniskelamin']=="Perempuan") echo "selected"?>>Perempuan</option>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Dasar Penerimaan</label>
                                <select class="form-control" name="penerimaan">
                                  <option value=""<?php if($rows['dasarpenerimaan']=="") echo "selected"?> disabled></option>
                                  <?php foreach ($dasarpenerimaan as $data): ?>
                                    <option value="<?=$data['pendidikan']?>"<?php if($data['pendidikan']==$rows['dasarpenerimaan']) echo "selected"?>><?=$data['pendidikan']?></option>
                                  <?php endforeach ?>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Agama</label>
                                <select class="form-control" name="agama">
                                  <option value=""<?php if($rows['agama']=="") echo "selected"?> disabled></option>
                                  <?php foreach ($agama as $data): ?>
                                    <option value="<?=$data['agama']?>"<?php if($data['agama']==$rows['agama']) echo "selected"?>><?=$data['agama']?></option>
                                  <?php endforeach ?>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Suku Bangsa</label>
                                <input type="text" class="form-control" name="suku" value="<?=$rows['sukubangsa']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Golongan Darah</label>
                                <select class="form-control" name="golongandarah">
                                  <option value=""<?php if($rows['golongandarah']=="") echo "selected"?> disabled></option>
                                  <option value="A"<?php if($rows['golongandarah']=="A") echo "selected"?>>A</option>
                                  <option value="AB"<?php if($rows['golongandarah']=="AB") echo "selected"?>>AB</option>
                                  <option value="B"<?php if($rows['golongandarah']=="B") echo "selected"?>>B</option>
                                  <option value="O"<?php if($rows['golongandarah']=="O") echo "selected"?>>O</option>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Tinggi Badan</label>
                                <input type="text" class="form-control" name="tinggibadan" value="<?=$rows['tinggibadan']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Berat Badan</label>
                                <input type="text" class="form-control" name="beratbadan" value="<?=$rows['beratbadan']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Hobi</label>
                                <input type="text" class="form-control" name="hobi" value="<?=$rows['hobi']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Motto Hidup</label>
                                <input type="text" class="form-control" name="motto" value="<?=$rows['mottohidup']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>No. KTP</label>
                                <input type="text" class="form-control" name="noktp" value="<?=$rows['noktp']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Alamat Sesuai KTP</label>
                                <input type="text" class="form-control" name="alamatktp" value="<?=$rows['alamatktp']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Alamat Sekarang</label>
                                <input type="text" class="form-control" name="alamatsekarang" value="<?=$rows['alamatsekarang']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email" value="<?=$rows['email']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Status</label>
                                <select class="form-control" name="status">
                                  <option value=""<?php if($rows['status']=="") echo "selected"?> disabled></option>
                                  <option value="Lajang"<?php if($rows['status']=="Lajang") echo "selected"?>>Lajang</option>
                                  <option value="Menikah"<?php if($rows['status']=="Menikah") echo "selected"?>>Menikah</option>
                                  <option value="Duda"<?php if($rows['status']=="Duda") echo "selected"?>>Duda</option>
                                  <option value="Janda"<?php if($rows['status']=="Janda") echo "selected"?>>Janda</option>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>No. KK</label>
                                <input type="text" class="form-control" name="nokk" value="<?=$rows['nokk']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>No. BPJS</label>
                                <input type="text" class="form-control" name="nobpjs" value="<?=$rows['bpjs']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>No. Sepatu</label>
                                <input type="text" class="form-control" name="nosepatu" value="<?=$rows['nosepatu']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Ukuran Seragam</label>
                                <select class="form-control" name="seragam">
                                  <option value=""<?php if($rows['ukuranseragam']=="") echo "selected"?> disabled></option>
                                  <option value="S"<?php if($rows['ukuranseragam']=="S") echo "selected"?>>S</option>
                                  <option value="M"<?php if($rows['ukuranseragam']=="M") echo "selected"?>>M</option>
                                  <option value="L"<?php if($rows['ukuranseragam']=="L") echo "selected"?>>L</option>
                                  <option value="XL"<?php if($rows['ukuranseragam']=="XL") echo "selected"?>>XL</option>
                                  <option value="XXL"<?php if($rows['ukuranseragam']=="XXL") echo "selected"?>>XXL</option>
                                </select>
                              </div>
                              <div class="form-group has-feedback">
                                <label>Nama Ibu Kandung</label>
                                <input type="text" class="form-control" name="namaibukandung" value="<?=$rows['namaibukandung']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Nama Ayah Kandung</label>
                                <input type="text" class="form-control" name="namaayahkandung" value="<?=$rows['namaayahkandung']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Keahlian Khusus</label>
                                <input type="text" class="form-control" name="keahliankhusus" value="<?=$rows['keahliankhusus']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Bahasa Yang Dikuasai</label>
                                <input type="text" class="form-control" name="bahasadikuasai" value="<?=$rows['bahasadikuasai']?>">
                              </div>
                              <div class="form-group has-feedback">
                                <label>Hasil Medical Checkup</label>
                                <select class="form-control" name="medical">
                                  <option value=""<?php if($rows['hasilmedical']=="") echo "selected"?> disabled></option>
                                  <option value="FIT"<?php if($rows['hasilmedical']=="FIT") echo "selected"?>>FIT</option>
                                  <option value="TIDAK FIT"<?php if($rows['hasilmedical']=="TIDAK FIT") echo "selected"?>>TIDAK FIT</option>
                                </select>
                              </div>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="keluarga">
                              <table class="table table-bordered" id="tabelkeluarga">
                                <label for="">Keluarga</label>
                                <thead>
                                  <tr>
                                    <th>Status</th>
                                    <th>Nama</th>
                                    <th>Tgl. Lahir</th>
                                    <th>Usia</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php foreach ($keluarga as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=$data['status']?></td>
                                      <td><?=$data['nama']?></td>
                                      <td><?=$data['tgllahir']?></td>
                                      <td><?=$data['usia']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="pendidikan">
                              <table class="table table-bordered" id="tabelpendidikan">
                                <label for="">Pendidikan</label>
                                <thead>
                                  <tr>
                                    <th>Jenis</th>
                                    <th>Keterangan</th>
                                    <th>Jurusan</th>
                                    <th>Thn. Lulus</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php foreach ($pendidikan as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=$data['jenis']?></td>
                                      <td><?=$data['keterangan']?></td>
                                      <td><?=$data['jurusan']?></td>
                                      <td><?=$data['thnlulus']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="diklat">
                              <table class="table table-bordered" id="tabeldiklat">
                                <label for="">Diklat</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Nama Diklat</th>
                                    <th>Tahun</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor2=0;
                                  foreach ($diklat as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor2?></td>
                                      <td><?=$data['namadiklat']?></td>
                                      <td><?=$data['tahun']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="karir">
                              <table class="table table-bordered" id="tabelkarir">
                                <label for="">Jenjang Karir</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Jabatan</th>
                                    <th>Tgl. SK</th>
                                    <th>No. SK</th>
                                    <th>Berakhir SK</th>
                                    <th>Keterangan</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor3=0; 
                                  foreach ($jenjangkarir as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor3?></td>
                                      <td><?=$data['jabatan']?></td>
                                      <td><?=$data['tglsk']?></td>
                                      <td><?=$data['nosk']?></td>
                                      <td><?=$data['berakhirsk']?></td>
                                      <td><?=$data['keterangan']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="kerja">
                              <table class="table table-bordered" id="tabelkerja">
                                <label for="">Pengalaman Kerja</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Pengalaman Kerja</th>
                                    <th>Tahun</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor4=0;
                                  foreach ($pengalamankerja as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor4?></td>
                                      <td><?=$data['pengalamankerja']?></td>
                                      <td><?=$data['tahun']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="organisasi">
                              <table class="table table-bordered" id="tabelorganisasi">
                                <label for="">Organisasi</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Organisasi</th>
                                    <th>Tahun</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor5=0;
                                  foreach ($organisasi as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor5?></td>
                                      <td><?=$data['organisasi']?></td>
                                      <td><?=$data['tahun']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="prestasi">
                              <table class="table table-bordered" id="tabelprestasi">
                                <label for="">Prestasi</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Prestasi</th>
                                    <th>Tahun</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor6=0;
                                  foreach ($prestasi as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor6?></td>
                                      <td><?=$data['prestasi']?></td>
                                      <td><?=$data['tahun']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="penghargaan">
                              <table class="table table-bordered" id="tabelpenghargaan">
                                <label for="">Penghargaan</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Penghargaan</th>
                                    <th>Tahun</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor7=0;
                                  foreach ($penghargaan as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor7?></td>
                                      <td><?=$data['penghargaan']?></td>
                                      <td><?=$data['tahun']?></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                            </section>
                            <br>
                            <hr>
                            <br>
                            <section class="sanksi">
                              <table class="table table-bordered tabelsanksi" id="tabelsanksi<?=$rows['nik']?>">
                                <label for="">Sanksi</label>
                                <thead>
                                  <tr>
                                    <th>No.</th>
                                    <th>Tgl. Sanksi</th>
                                    <th>Keterangan</th>
                                    <th>Berakhir</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $nomor8=0;
                                  foreach ($sanksi as $data): ?>
                                    <?php if ($data['nik']==$rows['nik']): ?>
                                    <tr>
                                      <td><?=++$nomor8?></td>
                                      <td><input style="border: hidden;" type="text" name="tglsanksi[]" value="<?=date("d-m-Y", strtotime($data['tglsanksi']))?>" readonly></td>
                                      <td><input style="border: hidden;" type="text" name="keterangan[]" value="<?=$data['keterangan']?>" readonly></td>
                                      <td><input style="border: hidden;" type="text" name="berakhir[]" value="<?=date("d-m-Y", strtotime($data['berakhir']))?>" readonly></td>
                                      <td><input style="border: hidden;" type="text" name="statussanksi[]" value="<?=$data['status']?>" readonly></td>
                                      <td><input class="btn btn-primary btn-xs" type="button" value="Hapus"></td>
                                    </tr>                                      
                                    <?php endif ?>
                                  <?php endforeach ?>
                                </tbody>
                              </table>
                              <button type="button" onclick="tambah('<?=$rows["nik"]?>')" class="btn btn-primary" style="float: right; margin-top: -10px;"><i class="fa fa-plus"></i> Tambah</button>
                              <br>
                            </section>
                            <br>
                            <hr>
                            <br>
                          </div>
                          <div class="modal-footer">
                            <a href="#" onclick="window.open('<?=base_url('index.php/hrd_controller/cetakBio/'.$rows['nik'])?>', 'newwindow', 'width=800,height=600');
                            return false;"><button type="button" class="btn btn-default" style="float: left;"><i class="fa fa-print"></i> Print</button></a>
                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Tutup</button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    </td>

                    <td><a href="#hakAkses<?=$rows['nik']?>" data-toggle="modal"><i class="fa fa-lock"></i></a>
                      <div id="hakAkses<?=$rows['nik']?>" class="modal fade hakAkses notPrint" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                        <div class="modal-dialog modal-sm" role="document">
                          <div class="modal-content" style="margin-top: 80%; margin-bottom: 80%;">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title">Hak Akses</h4>
                            </div>
                            <form action="<?=base_url('index.php/hrd_controller/do_changeaccess')?>" method="post">
                            <div class="modal-body">
                              <div class="form-group has-feedback">
                                <label>Akses</label>
                                <select class="form-control" name="akses">
                                  <option value="User">User</option>
                                  <option value="Admin Kabid">Admin Kabid</option>
                                  <option value="Admin HRD">Admin HRD</option>
                                </select>
                              </div>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Tutup</button>
                              <button type="submit" name="nik" value="<?=$rows['nik']?>" class="btn btn-primary"><i class="fa fa-save"></i> Simpan</button>
                            </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </td>
                    <td><a href="#hapusKaryawan<?=$rows['nik']?>" data-toggle="modal"><i class="fa fa-remove"></i></a>
                      <div id="hapusKaryawan<?=$rows['nik']?>" class="modal fade hapusKaryawan" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
                        <div class="modal-dialog modal-sm" role="document">
                          <div class="modal-content" style="margin-top: 80%; margin-bottom: 80%;">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                              <h4 class="modal-title">Hapus Karyawan</h4>
                            </div>
                            <div class="modal-body">
                              <label>Anda yakin ingin menghapus karyawan?</label>
                            </div>
                            <div class="modal-footer">
                              <form action="<?=base_url('index.php/hrd_controller/do_deletaccount')?>" method="post">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-close"></i> Tidak</button>
                              <button type="submit" name="nik" value="<?=$rows['nik']?>" class="btn btn-primary"><i class="fa fa-save"></i> Ya</button>
                              </form>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                <?php endforeach ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="#">Ganteng's Team</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
      </div>
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
</body>
</html>

<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo base_url();?>assets/bower_components/jquery/dist/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?php echo base_url();?>assets/bower_components/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo base_url();?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url();?>assets/bower_components/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo base_url();?>assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- daterangepicker -->
<script src="<?php echo base_url();?>assets/bower_components/moment/min/moment.min.js"></script>
<script src="<?php echo base_url();?>assets/bower_components/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="<?php echo base_url();?>assets/bower_components/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
<!-- Slimscroll -->
<script src="<?php echo base_url();?>assets/bower_components/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="<?php echo base_url();?>assets/bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url();?>assets/dist/js/adminlte.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?php echo base_url();?>assets/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url();?>assets/dist/js/demo.js"></script>

<script type="text/javascript" src="<?php echo base_url();?>assets/dist/Datatable/datatables.min.js"></script>

<script type="text/javascript">
  $(document).ready(function() {
      $('#pegawai').DataTable();
  });

  function tambah(y){
  $('#tabelsanksi'+y).append('<tr><td> - </td><td><input type="date" name="tglsanksi[]"></td><td><input type="text" name="keterangan[]"></td><td><input type="date" name="berakhir[]"></td><td><input type="text" name="statussanksi[]"></td><td><input class="btn btn-primary btn-xs" type="button" value="Hapus"></td></tr>')
  }

  $('.tabelsanksi').on('click', 'input[type="button"]', function () {
    $(this).closest('tr').remove();
  })

</script>

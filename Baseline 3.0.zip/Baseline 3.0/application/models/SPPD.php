<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SPPD extends CI_Model {

	function insert_SPPD($data){
		$this->db->insert('sppd',$data);
	}
	function get_SPPD(){
		$this->db->from('SPPD');
		$this->db->join('pegawai', 'pegawai.nik=sppd.nik_kabid');
		$this->db->where('sppd.status', "Diajukan");
		$query=$this->db->get();
		return $query->result_array();
	}
	function get_kabid_listSPPD($bidang){
		$this->db->from('SPPD');
		$this->db->join('pegawai', 'pegawai.nik=sppd.nik_kabid');
		$this->db->where('pegawai.bidang', $bidang);
		$this->db->order_by('nosppd', 'desc');
		return $this->db->get()->result_array();
	}

	function get_all_listSPPD(){
		$this->db->from('SPPD');
		$this->db->join('pegawai', 'pegawai.nik=sppd.nik_kabid');
		$this->db->order_by('nosppd', 'desc');
		return $this->db->get()->result_array();
	}

	function acc_SPPD($nosppd, $namahrd){
		$this->db->set('status', 'Dikonfirmasi');
		$this->db->set('penyetujuhrd', $namahrd);
		$this->db->set('terbaca', false);
		$this->db->where('nosppd', $nosppd);
		$this->db->update('SPPD');
	}

	function get_notifsppd(){
		$this->db->from('SPPD');
		$this->db->where('status', 'Dikonfirmasi');
		$this->db->where('terbaca', false);
		$this->db->where('nik_kabid', $this->session->userdata('nik'));
		$query=$this->db->get();
		return $query->num_rows();
	}
	function get_notifpengajuansppd(){
		$this->db->from('SPPD');
		$this->db->where('status', 'Diajukan');
		$this->db->where('terbaca', false);
		$query=$this->db->get();
		return $query->num_rows();
	}


	function updatenotifsppd(){
		$this->db->set('terbaca', true);
		$this->db->where('status', 'Dikonfirmasi');
		$this->db->where('nik_kabid', $this->session->userdata('nik'));
		$this->db->update('SPPD');
	}

		function updatepengajuansppd(){
		$this->db->set('terbaca', true);
		$this->db->where('status', 'Diajukan');
		$this->db->update('SPPD');
	}

	function get_infoprint($nosppd){
		$this->db->from('SPPD');
		$this->db->join('pegawai', 'pegawai.nik = SPPD.nik_kabid');
		$this->db->where('SPPD.nosppd', $nosppd);
		$query = $this->db->get();
		return $query->result_array();
	}



}
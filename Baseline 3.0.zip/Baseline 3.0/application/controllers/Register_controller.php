<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_controller extends CI_Controller {
	function __construct(){
		parent:: __construct();
		$this->load->model('pendaftaran_pegawai');
		$this->load->model('pegawai');
	}

	public function index()
	{
		$role=$this->session->userdata('role');

		if ($role == 'User') {
			redirect('karyawan_controller');
		}else if ($role == 'Admin Kabid') {
			redirect('kabid_controller');
		}else if ($role == 'Admin HRD') {
			redirect('hrd_controller');
		}else {
			$this->load->view('login');
		}
	}

	function do_register(){
		$nik = strtoupper($this->input->post('nik'));

		$password1 = $this->input->post('password1');
		$password1 = hash('sha256', sha1($password1));
		$password2 = $this->input->post('password2');
		$password2 = hash('sha256', sha1($password2));

		$check= $this->pegawai->cek_user($nik);

		if ($password1==$password2 && $check=='0'){
			$statuspegawai = $this->input->post('status');

			if($statuspegawai=='Kontrak'){
				$datetime_tglmasuk = new DateTime($this->input->post('tglmasuk'));
				$datetime_tglmasuk = date_add($datetime_tglmasuk, date_interval_create_from_date_string('90 days'));
				$tglbebascuti = $datetime_tglmasuk->format('Y/m/d');
			}
			else{
				$tglbebascuti = $this->input->post('tglmasuk');
			}

			$namalengkap = $this->input->post('fullname');
			$namapanggilan = $this->input->post('nickname');
			$bidang = $this->input->post('bidang');
			$tgllahir = $this->input->post('tgllahir');
			$tglmasuk = $this->input->post('tglmasuk');
			$dasarpenerimaan = $this->input->post('dasarpenerimaan');
			$tglpensiun=date("d-m-", strtotime($tgllahir));
			$tglpensiun.= date("Y", strtotime($tgllahir))+56;
			$data = array(
				'nik' => $nik,
				'password' => $password1,
				'namalengkap' => $namalengkap,
				'namapanggilan' => $namapanggilan,
				'statuspegawai' => $statuspegawai,
				'bidang' => $bidang,
				'tgllahir' => $tgllahir,
				'tglmasuk' => $tglmasuk,
				'tglpensiun'=>$tglpensiun, 
				'tglbebascuti' => $tglbebascuti,
				'sisacuti' => 8,
				'dasarpenerimaan'=>$dasarpenerimaan,
				'terbaca'=> false
			);
		$numrow = $this->pendaftaran_pegawai->cek_user($nik);
			if($numrow==0){
				$this->pendaftaran_pegawai->insert_pendaftaranpegawai($data);
			}else if ($numrow==1){
				$this->pendaftaran_pegawai->update_pendaftaranpegawai($data, $nik);
			}
				$this->session->set_flashdata('reportregister', '<br><font style="color:red;">Pendaftaran telah diajukan!</font>');
		}else{
			$this->session->set_flashdata('reportregister', '<br><font style="color:red;">Pendaftaran gagal mohon dicoba lagi!</font>');
		}
		redirect('login_controller/register');
	}

	function login(){
		$this->load->view('login.php');
	}
}
